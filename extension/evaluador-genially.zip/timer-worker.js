// Temporizador en un Worker: los Workers no se frenan cuando la pestaña está en segundo plano,
// y así la corrección sigue a buen ritmo aunque cambies de pestaña o de ventana.
onmessage = (e) => { const { id, ms } = e.data; setTimeout(() => postMessage(id), ms); };
