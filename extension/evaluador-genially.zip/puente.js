// Puente entre el Cuaderno de Evaluación (página web) y la extensión.
// Solo actúa en páginas que llevan <meta name="cuaderno-lomloe">.
(() => {
  const esCuaderno = () => !!document.querySelector('meta[name="cuaderno-lomloe"]');
  const marcar = () => { if (esCuaderno()) document.documentElement.setAttribute('data-genially-ext', chrome.runtime.getManifest().version); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', marcar); else marcar();

  const pend = new Map();
  const aPagina = (m) => window.postMessage({ origen: 'genially-ext', ...m }, '*');

  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (ev.source !== window || !d || d.origen !== 'cuaderno-lomloe' || !esCuaderno()) return;
    if (d.tipo === 'abrir-corrector') {
      try {
        chrome.runtime.sendMessage({ tipo: 'abrir-corrector', payload: d.payload }, (r) => {
          const err = chrome.runtime.lastError;
          aPagina({ tipo: 'respuesta', reqId: d.reqId, ok: !err && !!(r && r.ok), error: err ? err.message : (r && r.error) || '' });
        });
      } catch (e) { aPagina({ tipo: 'respuesta', reqId: d.reqId, ok: false, error: 'La extensión se ha actualizado: recarga esta página.' }); }
    } else if (d.tipo === 'ack') {
      const f = pend.get(d.reqId); if (f) { pend.delete(d.reqId); f(d); }
    }
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.tipo !== 'notas-genially') return;
    if (!esCuaderno()) { sendResponse({ ok: false, error: 'no es el cuaderno' }); return; }
    const reqId = 'n' + Date.now() + Math.random().toString(36).slice(2);
    const t = setTimeout(() => { pend.delete(reqId); sendResponse({ ok: false, error: 'el cuaderno no respondió' }); }, 5000);
    pend.set(reqId, (d) => { clearTimeout(t); sendResponse({ ok: !!d.ok, error: d.error || '', recibidas: d.recibidas || 0 }); });
    aPagina({ tipo: 'notas', reqId, ...msg.datos });
    return true;
  });
})();
