const $ = (i) => document.getElementById(i);
/*SLEEP_START*/
const sleep = (() => {
  const plain = (ms) => new Promise((r) => setTimeout(r, ms));
  try {
    const w = new Worker('timer-worker.js'), pend = new Map(); let n = 0, ok = true;
    w.onmessage = (e) => { const r = pend.get(e.data); if (r) { pend.delete(e.data); r.res(); } };
    w.onerror = () => { ok = false; pend.forEach((r) => setTimeout(r.res, r.ms)); pend.clear(); };
    return (ms) => (ok ? new Promise((res) => { const id = ++n; pend.set(id, { res, ms }); w.postMessage({ id, ms }); }) : plain(ms));
  } catch (e) { return plain; }
})();
/*SLEEP_END*/
const MAX_SLIDES = 150;   // tope de seguridad
const LIMIT = 16;         // elementos clicables que se prueban por diapositiva
const rep = { url: '', fecha: '', diapositivas: [], avisos: [] };
const S = { tabId: null, dbg: false, newTabs: [], path: {} };

/* ================= Esta función se ejecuta DENTRO del Genially ================= */
async function inject(mode, arg) {
  const w = (ms) => new Promise((r) => setTimeout(r, ms));
  const A = (window.__anz = window.__anz || { ids: new WeakMap(), n: 0, anim: new Map(), timer: null });
  const cn = (e) => (typeof e.className === 'string' ? e.className : '');
  const lab = (e) => e.getAttribute('aria-label') || '';
  const GOTO = /p[aá]gina\s*(\d+)|page\s*(\d+)|slide\s*(\d+)|diapositiva\s*(\d+)/i;
  const DLG = /dialog|modal|popup|pop-up|overlay|window|lightbox/i;
  const UI = /fullscreen|pantalla|compart|share|cookie|cerrar|close|visualizar/i;
  const skip = (e) => e.closest('#onetrust-consent-sdk,[class*="ot-"]') || /(^| )ot-/.test(cn(e));
  const vis = (e) => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e); return r.width >= 1 && r.height >= 1 && cs.display !== 'none' && cs.visibility !== 'hidden'; };
  const inView = (r) => r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight;
  const shown = (e) => {
    const r = e.getBoundingClientRect();
    if (r.width < 4 || r.height < 4 || !inView(r)) return false;
    if (getComputedStyle(e).visibility === 'hidden') return false;
    for (let p = e; p && p !== document.body; p = p.parentElement) { const cs = getComputedStyle(p); if (cs.display === 'none' || +cs.opacity < 0.05) return false; }
    return true;
  };
  const pageInfo = () => {
    const re = /P[aá]gina\s+(\d+)\s+de\s+(\d+)/i; let m = null;
    for (const e of document.querySelectorAll('[aria-live],[role=status],[role=alert]')) { m = (e.textContent || '').match(re); if (m) break; }
    if (!m) { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { const p = n.parentElement; if (p && /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName)) continue; m = (n.nodeValue || '').match(re); if (m) break; } }
    return m ? { n: +m[1], m: +m[2] } : null;
  };
  const roots = () => {
    const all = [...document.querySelectorAll('.genially-view-slide-container')];
    const v = all.filter((e) => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e); return r.width > 1 && r.height > 1 && inView(r) && cs.visibility !== 'hidden' && cs.display !== 'none'; });
    return v.length ? v : (all.length ? all : [document.body]);
  };
  const within = (e, rs) => rs.some((r) => r.contains(e));
  const elId = (e) => { if (!A.ids.has(e)) A.ids.set(e, ++A.n); return A.ids.get(e); };
  const desc = (e) => e.tagName.toLowerCase() + '.' + cn(e).split(/\s+/).slice(0, 2).join('.') + (lab(e) ? ' [' + lab(e).slice(0, 30) + ']' : '');
  const absUrl = (u) => { try { return new URL(u, location.href).href; } catch (e) { return u; } };
  const fire = (el) => ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach((t) => el.dispatchEvent(new (t.startsWith('pointer') ? PointerEvent : MouseEvent)(t, { bubbles: true, cancelable: true, view: window })));
  const keyEv = (t, k, c) => t.dispatchEvent(new KeyboardEvent('keydown', { key: k, code: k, keyCode: c, which: c, bubbles: true, cancelable: true }));
  const rec = (e, id) => {
    e.setAttribute('data-anz', id);
    const r = e.getBoundingClientRect(), cx = Math.round(r.x + r.width / 2), cy = Math.round(r.y + r.height / 2);
    const top = document.elementFromPoint(cx, cy);
    return { id, cx, cy, hit: !!top && (top === e || e.contains(top)), label: lab(e).slice(0, 80), tag: e.tagName, cls: cn(e).slice(0, 60) };
  };

  const texts = (rs) => {
    const o = [];
    rs.forEach((r) => {
      const t = document.createTreeWalker(r, NodeFilter.SHOW_TEXT); let n;
      while ((n = t.nextNode())) {
        const p = n.parentElement; if (!p || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName) || skip(p)) continue;
        const x = (n.nodeValue || '').replace(/\s+/g, ' ').trim(); if (x.length > 1) o.push(x);
      }
    });
    return [...new Set(o)];
  };

  const fontsOf = (rs) => {
    const o = {};
    rs.forEach((r) => { const w = document.createTreeWalker(r, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) {
      const p = n.parentElement; if (!p || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName) || skip(p) || !shown(p)) continue;
      if ((n.nodeValue || '').replace(/\s+/g, ' ').trim().length < 2) continue;
      const fam = (getComputedStyle(p).fontFamily || '').split(',')[0].replace(/["']/g, '').trim();
      if (fam) o[fam] = (o[fam] || 0) + 1;
    } });
    return o;
  };
  const colorsOf = (rs) => {
    const o = {};
    rs.forEach((r) => { const w = document.createTreeWalker(r, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) {
      const p = n.parentElement; if (!p || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName) || skip(p) || !shown(p)) continue;
      if ((n.nodeValue || '').replace(/\s+/g, ' ').trim().length < 2) continue;
      const m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)(?:[ ,/]+([\d.]+))?/.exec(getComputedStyle(p).color || ''); if (!m || (m[4] !== undefined && +m[4] === 0)) continue;
      const hex = '#' + [m[1], m[2], m[3]].map((v) => (+v).toString(16).padStart(2, '0')).join('');
      o[hex] = (o[hex] || 0) + 1;
    } });
    return o;
  };
  const bigTitle = (rs) => {
    let best = '', bs = 0;
    rs.forEach((r) => { const w = document.createTreeWalker(r, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) {
      const p = n.parentElement; if (!p || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName) || skip(p)) continue;
      const x = (n.nodeValue || '').replace(/\s+/g, ' ').trim(); if (x.length < 3 || !shown(p)) continue;
      const fs = parseFloat(getComputedStyle(p).fontSize) || 0; if (fs > bs) { bs = fs; best = x; }
    } });
    return best;
  };
  const imgs = (rs) => {
    const out = [], seen = new Set();
    const add = (e, url, kind) => {
      if (!url) return;
      const it = e.closest('.genially-view-item'), item = it ? (it.id || '') : '';
      const k = item + '|' + absUrl(url); if (seen.has(k)) return; seen.add(k);
      out.push({ url: absUrl(url), kind: it ? kind : 'fondo', item, alt: (e.getAttribute('alt') || e.getAttribute('aria-label') || '').slice(0, 80) });
    };
    rs.forEach((root) => [root, ...root.querySelectorAll('*')].forEach((e) => {
      if (skip(e)) return;
      const tag = e.tagName.toLowerCase();
      if (tag === 'img') { if (shown(e)) add(e, e.currentSrc || e.src, 'img'); return; }
      if (tag === 'image') { if (shown(e)) add(e, e.getAttribute('href') || e.getAttributeNS('http://www.w3.org/1999/xlink', 'href'), 'svg'); }
      else if (tag === 'video' && e.poster && shown(e)) add(e, e.poster, 'poster');
      if (!shown(e) && e !== root) return;
      const bg = getComputedStyle(e).backgroundImage;
      if (bg && bg !== 'none') { const re = /url\((['"]?)(.*?)\1\)/g; let m; while ((m = re.exec(bg))) add(e, m[2], 'img'); }
    }));
    return out;
  };
  const links = (rs) => {
    const ext = [], int = [], seen = new Set();
    rs.forEach((root) => {
      root.querySelectorAll('a[href]').forEach((a) => {
        if (skip(a)) return;
        const h = a.getAttribute('href') || ''; if (!h || /^javascript:/i.test(h)) return;
        const o = { href: a.href.slice(0, 200), texto: (a.innerText || lab(a) || '').replace(/\s+/g, ' ').trim().slice(0, 60), via: 'enlace <a>' };
        const k = o.href + o.texto; if (seen.has(k)) return; seen.add(k);
        (h.startsWith('#') ? int : ext).push(o);
      });
      root.querySelectorAll('[data-href],[data-url],[data-link]').forEach((e) => {
        if (skip(e)) return;
        const h = e.dataset.href || e.dataset.url || e.dataset.link; const k = h + '|d'; if (!h || seen.has(k)) return; seen.add(k);
        ext.push({ href: h.slice(0, 200), texto: lab(e).slice(0, 60), via: 'atributo data-*' });
      });
    });
    return { ext, int };
  };

  const sid = (e) => { const w = e.closest('[data-item-id]'); return w ? w.getAttribute('data-item-id') : 'e' + elId(e); };
  const mat = (tf) => {
    if (!tf || tf === 'none') return { sc: 1, rot: 0, tx: 0, ty: 0 };
    const n = (tf.match(/-?\d*\.?\d+(?:e-?\d+)?/gi) || []).map(Number);
    if (/matrix3d/.test(tf) && n.length >= 16) return { sc: Math.hypot(n[0], n[1]), rot: Math.atan2(n[1], n[0]) * 180 / Math.PI, tx: n[12], ty: n[13] };
    if (n.length >= 6) return { sc: Math.hypot(n[0], n[1]), rot: Math.atan2(n[1], n[0]) * 180 / Math.PI, tx: n[4], ty: n[5] };
    return { sc: 1, rot: 0, tx: 0, ty: 0 };
  };
  const kindsOf = (states) => {
    const vs = states.filter((x) => x.vis !== 'hidden'); if (vs.length < 2) return [];
    const ms = vs.map((x) => mat(x.tf)), rg = (f) => { const v = ms.map(f); return Math.max(...v) - Math.min(...v); }, k = [];
    if (vs.some((x) => x.op > 0.03 && x.op < 0.97)) k.push('Fundido');
    if (rg((m) => m.sc) > 0.03) k.push('Zoom');
    if (rg((m) => m.rot) > 3) k.push('Giro');
    if (Math.hypot(rg((m) => m.tx), rg((m) => m.ty)) > 3) k.push('Desplazamiento');
    return k;
  };
  const animCollect = (final) => {
    if (final) { clearInterval(A.timer); A.timer = null; if (A.mo) A.mo.disconnect(); }
    A.anim.forEach((r, el) => { if (!el.isConnected) A.anim.delete(el); });
    (A.mut || new Map()).forEach((st, el) => { if (!el.isConnected) A.mut.delete(el); });
    const rs = roots(), items = [], seen = new Set(), debug = [];
    const push = (e, type, src, inf) => { if (!shown(e)) return; const k = sid(e) + '|' + type; if (seen.has(k)) return; seen.add(k); items.push({ id: sid(e), el: desc(e), type, src, infinite: !!inf }); };
    A.anim.forEach((r, el) => { if (within(el, rs)) r.forEach((m, type) => push(el, type, 'api', m.inf)); });
    (A.mut || new Map()).forEach((st, el) => {
      if (!within(el, rs)) return;
      const k = kindsOf(st);
      if (k.length) { push(el, k.join(' + '), 'mutación', false); if (debug.length < 8) debug.push('ANIM ' + sid(el).slice(0, 8) + ': ' + st.length + ' cambios de estilo → ' + k.join('+')); }
    });
    rs.forEach((root) => [root, ...root.querySelectorAll('*')].forEach((e) => {
      if (skip(e)) return;
      const an = getComputedStyle(e).animationName;
      if (an && an !== 'none') an.split(',').forEach((x) => push(e, x.trim(), 'css'));
      e.getAttributeNames().filter((x) => /^data-.*anim/i.test(x)).forEach((x) => push(e, (e.getAttribute(x) || x).slice(0, 40), 'atributo'));
    }));
    return { items, debug };
  };
  if (mode === 'author') {       // nombre del autor: texto situado justo antes de «Created on / Creado el…»; si no, un nombre entre paréntesis en el título
    const DATE = /^\s*(created on|created|creado( el)?|criado( em)?|créé( le)?|erstellt( am)?|creato( il)?|creat)\b/i;
    const w = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT), tx = []; let n;
    while ((n = w.nextNode())) { const p = n.parentElement; if (p && /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(p.tagName)) continue; const t = (n.nodeValue || '').replace(/\s+/g, ' ').trim(); if (t) tx.push(t); }
    let texto = null; for (let i = 1; i < tx.length; i++) if (DATE.test(tx[i]) && tx[i - 1].length <= 80 && !DATE.test(tx[i - 1])) { texto = tx[i - 1]; break; }
    const m = /\(([^()]{3,60})\)\s*(\|[^|]*)?$/.exec(document.title || '');
    return (texto || m) ? { texto, titulo: m ? m[1].trim() : null } : null;
  }
  if (mode === 'frame') return { ready: document.readyState, containers: document.querySelectorAll('.genially-view-slide-container').length };
  if (mode === 'fp') { const rs = roots(); return [...texts(rs).slice(0, 60), ...imgs(rs).map((i) => 'IMG:' + i.url)]; }
  if (mode === 'slide') {
    const rs = roots(), t = texts(rs);
    const items = [];
    rs.forEach((root) => root.querySelectorAll('.genially-view-item').forEach((e) => {
      const r = e.getBoundingClientRect();
      items.push({ id: e.id || '', tipo: e.getAttribute('data-noddus-item-name') || '(sin nombre)', cy: e.getAttribute('data-cy') || '', anim: !!e.closest('.genially-animated-wrapper'), visible: vis(e), pointer: getComputedStyle(e).cursor === 'pointer', rect: [r.x, r.y, r.width, r.height].map(Math.round) });
    }));
    return { titulo: t[0] || '', texts: t.slice(0, 6), images: imgs(rs), links: links(rs), containers: rs.length, items };
  }
  if (mode === 'pages') {
    document.querySelectorAll('[data-anz^="p"]').forEach((e) => e.removeAttribute('data-anz'));
    const by = new Map();
    document.querySelectorAll('[aria-label]').forEach((e) => {
      const m = lab(e).match(GOTO); if (!m || skip(e) || e.closest('.genially-view-slide-container')) return;
      const n = +(m[1] || m[2] || m[3] || m[4]); if (!by.has(n) || (!vis(by.get(n)) && vis(e))) by.set(n, e);
    });
    return [...by].map(([n, e]) => ({ n, ...rec(e, 'p' + n) }));
  }
  if (mode === 'next') {
    const e = [...document.querySelectorAll('[aria-label],[title],button,[role=button]')].find((x) => !skip(x) && !x.closest('.genially-view-slide-container') && vis(x) && /next|siguiente|flecha|arrow/i.test(lab(x) + (x.title || '') + cn(x)) && !/prev|anterior/i.test(lab(x) + (x.title || '') + cn(x)));
    return e ? rec(e, 'nx') : null;
  }
  if (mode === 'arrow') {        // flecha lateral de navegación (siguiente / anterior), fuera de los elementos de la diapositiva
    const NEXT = /next|siguiente|adelante|forward|derech|right|avanz/i, PREV = /prev|anterior|atr[aá]s|back|izquierd|left|retroced/i;
    const want = arg === 'prev' ? PREV : NEXT, other = arg === 'prev' ? NEXT : PREV;
    const attrs = (x) => [lab(x), x.title || ''].join(' '), more = (x) => [cn(x), x.getAttribute('data-cy') || '', x.getAttribute('data-testid') || '', x.id || ''].join(' ');
    const c = [...document.querySelectorAll('button,[role=button],a,[aria-label],[title],[class*="arrow" i],[class*="chevron" i],[class*="nav" i]')].filter((x) => {
      if (skip(x) || !vis(x) || x.closest('.genially-view-item')) return false;
      const r = x.getBoundingClientRect(); if (r.width > 240 || r.height > 240) return false;
      const t1 = attrs(x), t2 = more(x);
      if (GOTO.test(t1)) return false;
      if (want.test(t1) && !other.test(t1)) return true;
      return /arrow|chevron|nav/i.test(t2) && want.test(t2) && !other.test(t2);
    });
    c.sort((a, b) => (want.test(attrs(b)) ? 1 : 0) - (want.test(attrs(a)) ? 1 : 0));
    return c.length ? rec(c[0], 'ar') : null;
  }
  if (mode === 'clickables') {
    document.querySelectorAll('[data-anz^="c"]').forEach((e) => e.removeAttribute('data-anz'));
    const rs = roots(), set = new Set(), area = innerWidth * innerHeight;
    const gotoEls = [];
    document.querySelectorAll('[aria-label]').forEach((e) => { if (!skip(e) && GOTO.test(lab(e)) && e.closest('.genially-view-slide-container')) { set.add(e); gotoEls.push(e); } });
    rs.forEach((root) => [...root.querySelectorAll('*')].forEach((e) => {
      if (skip(e) || !vis(e)) return;
      const r = e.getBoundingClientRect();
      if (!inView(r) || r.width * r.height > 0.8 * area) return;
      if (e.closest('a[href^="http"]') || UI.test(lab(e) + cn(e))) return;
      if (getComputedStyle(e).cursor === 'pointer' || e.getAttribute('role') === 'button' || e.tagName === 'BUTTON' || /cursor-pointer/.test(cn(e))) set.add(e);
    }));
    let fallback = false;
    if (!set.size) {
      fallback = true;
      rs.forEach((root) => root.querySelectorAll('.genially-view-item').forEach((e) => {
        const r = e.getBoundingClientRect();
        if (r.width < 8 || r.height < 8 || r.width * r.height > 0.8 * area || !inView(r) || skip(e)) return;
        if (/^(imagen|image|fondo)/i.test(e.getAttribute('data-noddus-item-name') || '') && r.width * r.height > 0.5 * area) return;
        set.add(e);
      }));
    }
    const outer = [...set].filter((e) => { let p = e.parentElement; while (p) { if (set.has(p)) return false; p = p.parentElement; } return true; });
    const g = (e) => (GOTO.test(lab(e)) ? 0 : 1);
    outer.sort((a, b) => { const x = a.getBoundingClientRect(), y = b.getBoundingClientRect(); return (g(a) - g(b)) || (x.y - y.y) || (x.x - y.x); });
    return outer.map((e, i) => ({ ...rec(e, 'c' + i), total: outer.length, fallback }));
  }
  if (mode === 'diag') {
    const rs = roots(), info = (e) => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e); return { el: desc(e), rect: [r.x, r.y, r.width, r.height].map(Math.round), display: cs.display, visibility: cs.visibility, opacity: cs.opacity, pe: cs.pointerEvents, cursor: cs.cursor, html: e.outerHTML.slice(0, 260) }; };
    const gotos = [...document.querySelectorAll('[aria-label]')].filter((e) => GOTO.test(lab(e)) && !skip(e)).slice(0, 8).map((e) => ({ ...info(e), dentroSlide: !!e.closest('.genially-view-slide-container') }));
    const ptr = []; rs.forEach((root) => root.querySelectorAll('*').forEach((e) => { if (ptr.length < 12 && !skip(e) && getComputedStyle(e).cursor === 'pointer') ptr.push(info(e)); }));
    return { viewport: [innerWidth, innerHeight], roots: rs.map(info), gotos, pointer: ptr, ariaLabels: [...new Set([...document.querySelectorAll('[aria-label]')].map(lab))].slice(0, 40) };
  }
  if (mode === 'closers') {
    document.querySelectorAll('[data-anz^="x"]').forEach((e) => e.removeAttribute('data-anz'));
    return [...document.querySelectorAll('[aria-label*="close" i],[aria-label*="cerrar" i],[class*="close" i]')].filter((e) => !skip(e) && vis(e)).map((e, i) => rec(e, 'x' + i));
  }
  if (mode === 'fire') { const e = document.querySelector('[data-anz="' + arg + '"]'); if (e) fire(e); return !!e; }
  if (mode === 'esc') { keyEv(document.body, 'Escape', 27); return true; }
  if (mode === 'before') {
    A.t0 = new Set(texts([document.body])); A.e0 = new Set(document.querySelectorAll('*')); A.i0 = new Set(imgs([document.body]).map((i) => i.url)); return true;
  }
  if (mode === 'after') {
    const cur = texts([document.body]), curSet = new Set(cur);
    const nuevos = cur.filter((x) => !A.t0.has(x)), removed = [...A.t0].filter((x) => !curSet.has(x));
    const ci = [...new Set(imgs([document.body]).map((i) => i.url))], ciSet = new Set(ci);
    const nImgs = ci.filter((u) => !A.i0.has(u)), rImgs = [...A.i0].filter((u) => !ciSet.has(u));
    const nel = [...document.querySelectorAll('*')].filter((e) => !A.e0.has(e));
    const dlg = nel.filter((e) => !skip(e) && DLG.test(cn(e) + (e.getAttribute('role') || '')));
    const rT = A.t0.size ? removed.length / A.t0.size : 0, rI = A.i0.size >= 2 ? rImgs.length / A.i0.size : 0;
    return { nuevosTextos: nuevos.slice(0, 8), nuevasImagenes: nImgs.slice(0, 8), dialogos: dlg.length, elementosNuevos: nel.length, pageChanged: rT > 0.6 || rI > 0.6, titulo: texts(roots())[0] || '' };
  }
  if (mode === 'where') {
    const rs = roots(), cr = rs[0].getBoundingClientRect(), p = arg || {};
    const abs = (rx, ry) => ({ x: Math.round(cr.x + rx * cr.width), y: Math.round(cr.y + ry * cr.height) });
    const items = [...document.querySelectorAll('.genially-view-item')].filter((e) => !skip(e) && shown(e) && within(e, rs));
    let best = null, how = '';
    const byId = p.itemId && items.find((e) => e.id === p.itemId);
    if (byId) { best = byId; how = 'mismo elemento'; }
    else {
      let bd = 1e9;
      items.forEach((e) => {
        if ((e.getAttribute('data-noddus-item-name') || '') !== (p.tipo || '') && (e.getAttribute('data-cy') || '') !== (p.cy || '')) return;
        const r = e.getBoundingClientRect();
        const d = Math.hypot((r.x + r.width / 2 - cr.x) / cr.width - p.rx, (r.y + r.height / 2 - cr.y) / cr.height - p.ry);
        const tx = (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 60);
        const dd = d + (p.texto && tx !== p.texto ? 0.05 : 0);
        if (d < 0.12 && dd < bd) { bd = dd; best = e; }
      });
      if (best) how = 'elemento equivalente';
    }
    if (best) {
      const r = best.getBoundingClientRect(), pt = abs((r.x + r.width / 2 - cr.x) / cr.width, (r.y + r.height / 2 - cr.y) / cr.height);
      const top = document.elementFromPoint(pt.x, pt.y);
      return { ...pt, how, found: true, hit: !!top && (best.contains(top) || top.contains(best)) };
    }
    return { ...abs(p.px, p.py), how: 'posición', found: false, hit: false };
  }
  if (mode === 'quiet') {
    let running = 0;
    try { running = document.getAnimations().filter((a) => a.playState === 'running' && a.effect && a.effect.getComputedTiming().iterations !== Infinity).length; } catch (e) {}
    return { quiet: A.lastMut ? Date.now() - A.lastMut : 99999, running };
  }
  if (mode === 'clickAt') { const e = document.elementFromPoint(arg.x, arg.y); if (e) fire(e); return !!e; }
  if (mode === 'hook' || mode === 'ensure') {
    if (!A.hooked) {
      A.hooked = true; A.clicks = [];
      document.addEventListener('click', (ev) => {
        const t = ev.target; if (!t || !t.closest) return;
        const e = t.closest('.genially-view-item,[aria-label],button,a') || t;
        const nm = (e.getAttribute('data-noddus-item-name') || e.tagName.toLowerCase()) + (lab(e) ? ' «' + lab(e).slice(0, 40) + '»' : '') + ((e.innerText || '').trim() ? ' "' + (e.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 30) + '"' : '');
        const it = t.closest('.genially-view-item'); let pos = null;
        try {
          const rs0 = roots(), cr = rs0[0].getBoundingClientRect(), ir = (it || t).getBoundingClientRect();
          if (cr.width > 0 && cr.height > 0) pos = { itemId: it ? it.id : '', tipo: it ? (it.getAttribute('data-noddus-item-name') || '') : '', cy: it ? (it.getAttribute('data-cy') || '') : '', texto: ((it || t).innerText || '').replace(/\s+/g, ' ').trim().slice(0, 60), rx: +((ir.x + ir.width / 2 - cr.x) / cr.width).toFixed(4), ry: +((ir.y + ir.height / 2 - cr.y) / cr.height).toFixed(4), px: +((ev.clientX - cr.x) / cr.width).toFixed(4), py: +((ev.clientY - cr.y) / cr.height).toFixed(4) };
        } catch (e) {}
        A.clicks.push({ t: Date.now(), name: nm, itemId: it ? it.id : '', pos, inSlide: !!t.closest('.genially-view-slide-container') });
        if (A.clicks.length > 30) A.clicks.shift();
      }, true);
    }
    if (mode === 'hook' || A.timer) return true;
    mode = 'animStart';
  }
  if (mode === 'animStart') {
    A.anim.clear(); clearInterval(A.timer);
    const tick = () => {
      try {
        document.getAnimations().forEach((a) => {
          const ef = a.effect, el = ef && ef.target; if (!el || skip(el)) return;
          const isT = typeof CSSTransition !== 'undefined' && a instanceof CSSTransition;
          if (isT && !el.closest('.genially-animated-wrapper')) return;
          let type = isT ? 'transición(' + a.transitionProperty + ')' : a.animationName;
          if (!type) { try { const p = new Set(); ef.getKeyframes().forEach((k) => Object.keys(k).forEach((x) => { if (!['offset', 'easing', 'composite', 'computedOffset'].includes(x)) p.add(x); })); type = 'WAAPI(' + [...p].join(',') + ')'; } catch (e) { type = 'WAAPI'; } }
          let r = A.anim.get(el); if (!r) { r = new Map(); A.anim.set(el, r); }
          const t = ef.getComputedTiming(); r.set(type, { inf: t.iterations === Infinity });
        });
      } catch (e) {}
    };
    if (A.mo) A.mo.disconnect(); A.mut = new Map();
    A.mo = new MutationObserver((ms) => { A.lastMut = Date.now(); ms.forEach((m) => {
      const t = m.target, wr = t.closest && t.closest('.genially-animated-wrapper'); if (!wr) return;
      const cs = getComputedStyle(wr); let st = A.mut.get(wr); if (!st) { st = []; A.mut.set(wr, st); }
      if (st.length < 150) st.push({ vis: cs.visibility, op: +cs.opacity, tf: cs.transform });
    }); });
    A.mo.observe(document.body, { attributes: true, attributeFilter: ['style'], subtree: true });
    tick(); A.timer = setInterval(tick, 70); return true;
  }

  if (mode === 'animStop') return animCollect(true);
  if (mode === 'collect') {
    const rs = roots(), its = [];
    rs.forEach((root) => root.querySelectorAll('.genially-view-item').forEach((e) => {
      if (skip(e) || !shown(e)) return;
      const cy = e.getAttribute('data-cy') || '';
      its.push({ id: e.id || '', tipo: e.getAttribute('data-noddus-item-name') || '(sin nombre)', cy, texto: (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 100), imgs: cy === 'imageItemView' ? imgs([e]).map((i) => i.url) : [] });
    }));
    return { page: pageInfo(), titulo: bigTitle(rs), texts: texts(rs).slice(0, 6), images: imgs(rs), links: links(rs), items: its, anim: animCollect(false), clicks: (A.clicks || []).slice(-8), now: Date.now(), containers: rs.length, fonts: fontsOf(rs), colors: colorsOf(rs), alltexts: texts(rs).slice(0, 120), vis: document.visibilityState };
  }
}

/* ================= Utilidades del lado de la extensión ================= */
async function call(mode, arg) {
  const r = await chrome.scripting.executeScript({ target: { tabId: S.tabId }, func: inject, args: [mode, arg || null] });
  return r[0].result;
}
const send = (m, p) => chrome.debugger.sendCommand({ tabId: S.tabId }, m, p);
async function mouse(x, y) { for (const t of ['mouseMoved', 'mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type: t, x, y, button: 'left', buttons: t === 'mouseReleased' ? 0 : 1, clickCount: 1 }); }
async function key(k, vk) {
  if (S.dbg) { for (const t of ['keyDown', 'keyUp']) await send('Input.dispatchKeyEvent', { type: t, key: k, code: k, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk }); }
  else if (k === 'Escape') await call('esc');
}
async function clickRec(r) { if (S.dbg && r.hit) await mouse(r.cx, r.cy); else await call('fire', r.id); }
function sim(a, b) {
  const A = new Set(a || []), B = new Set(b || []); if (!A.size && !B.size) return 1;
  let i = 0; A.forEach((x) => { if (B.has(x)) i++; }); return i / (A.size + B.size - i);
}
const log = (m) => { $('st').textContent = m; };
const imgName = (i) => {
  try {
    if (i.url.startsWith('data:')) return i.alt || '(imagen incrustada en el propio Genially)';
    const p = new URL(i.url).pathname.split('/').filter(Boolean).pop() || '';
    return decodeURIComponent(p) || i.alt || i.url.slice(0, 60);
  } catch (e) { return i.url.slice(0, 60); }
};
const fps = {};

/* ================= Navegación ================= */
async function waitSlides() { await sleep(2000); for (let k = 0; k < 30; k++) { try { const f = await call('frame'); if (f.containers) return; } catch (e) {} await sleep(1000); } }
async function doStep(st) {
  if (st.t === 'jump') { const cl = await call('clickables'); if (cl[st.idx]) await clickRec(cl[st.idx]); }
  else if (st.t === 'page') { const b = (await call('pages')).find((x) => x.n === st.n); if (b) await clickRec(b); }
  else if (st.t === 'key') await key('ArrowRight', 39);
  else if (st.t === 'next') { const n = await call('next'); if (n) await clickRec(n); }
}
async function replay(i) {
  await chrome.tabs.reload(S.tabId); await waitSlides(); await call('animStart'); await sleep(2500);
  for (const st of S.path[i] || []) { await doStep(st); await sleep(1700); }
  const f = await call('fp'); return sim(f, fps[i]) > 0.75;
}
async function goTo(i) {
  let f = await call('fp'); if (sim(f, fps[i]) > 0.85) return true;
  const b = (await call('pages')).find((x) => x.n === i);
  if (b) { await clickRec(b); await sleep(1500); f = await call('fp'); if (sim(f, fps[i]) > 0.8) return true; }
  return replay(i);   // recarga el Genially y repite el camino hasta la diapositiva i
}
const visited = (f) => Object.values(fps).some((x) => sim(f, x) > 0.85);
async function advance(i, fpCur, rec) {
  // 1) botones/elementos de la propia diapositiva que llevan a otra página
  for (const j of rec.saltos || []) {
    if (visited(j.fp)) continue;
    const cl = await call('clickables'); if (!cl[j.idx]) continue;
    await clickRec(cl[j.idx]); await sleep(1800);
    const f = await call('fp');
    if (sim(f, j.fp) > 0.7 && sim(f, fpCur) < 0.85) return { fp: f, step: { t: 'jump', idx: j.idx, fp: j.fp } };
    if (!(await goTo(i))) return null;
  }
  // 2) navegación general
  const tries = [
    [async () => { const b = (await call('pages')).find((x) => x.n === i + 1); if (!b) return false; await clickRec(b); return true; }, { t: 'page', n: i + 1 }],
    [async () => { await key('ArrowRight', 39); return true; }, { t: 'key' }],
    [async () => { const n = await call('next'); if (!n) return false; await clickRec(n); return true; }, { t: 'next' }]
  ];
  for (const [fn, step] of tries) {
    if (!(await fn())) continue;
    await sleep(1500);
    const f = await call('fp');
    if (sim(f, fpCur) < 0.85) return { fp: f, step };
  }
  return null;
}

/* ================= Análisis de una diapositiva ================= */
function buildSlide(n, snap, an) {
  const imgs = new Map();
  snap.images.forEach((i) => { const nm = imgName(i), k = nm + '|' + i.url; if (!imgs.has(k)) imgs.set(k, { nombre: nm, url: i.url, tipo: i.kind, veces: 0 }); imgs.get(k).veces++; });
  const tipos = {}, els = new Set(); let inf = 0;
  an.items.forEach((a) => { els.add(a.id); (tipos[a.type] = tipos[a.type] || new Set()).add(a.id); if (a.infinite) inf++; });
  return {
    n, titulo: snap.titulo, textos: snap.texts,
    imagenes: { total: snap.images.length, distintas: imgs.size, lista: [...imgs.values()], enEmergentes: [] },
    enlaces: { internos: snap.links.int, externos: snap.links.ext },
    animaciones: { total: els.size, tipos: Object.fromEntries(Object.entries(tipos).map(([k, v]) => [k, v.size])), infinitas: inf, detalle: an.items.slice(0, 40), debugClases: an.debug },
    popups: [], sinEfecto: 0, probados: 0, notas: [], saltos: [], elementos: snap.items || []
  };
}

async function closePopup(i, base) {
  await key('Escape', 27); await call('esc'); await sleep(350);
  let f = await call('fp'); if (sim(f, base) >= 0.85) return true;
  const cs = (await call('closers')).reverse().slice(0, 3);
  for (const c of cs) { await clickRec(c); await sleep(500); f = await call('fp'); if (sim(f, base) >= 0.85) return true; }
  return false;
}

async function testInteractions(i, rec, win) {
  const base = fps[i];
  const cl = await call('clickables');
  if (cl.length && cl[0].fallback) rec.notas.push('No se detectaron elementos con cursor de mano; se probó a pulsar los elementos de la diapositiva uno a uno.');
  if (!cl.length || i === 1) rec.diag = await call('diag');
  const tested = cl.slice(0, LIMIT);
  if (cl.length > LIMIT) rec.notas.push('Se probaron ' + LIMIT + ' de ' + cl.length + ' elementos clicables; puede haber más ventanas emergentes.');
  const seen = new Map();
  for (const c of tested) {
    S.newTabs.length = 0;
    await call('before');
    await clickRec(c); await sleep(900);
    rec.probados++;
    const a = await call('after');
    const lbl = c.label || (c.cls || c.tag);
    if (S.newTabs.length) {
      rec.enlaces.externos.push({ href: S.newTabs[0].url || '(se abre otra pestaña)', texto: lbl, via: 'clic (abre pestaña)' });
      try { await chrome.windows.update(win.id, { focused: true }); } catch (e) {}
      continue;
    }
    if (a.pageChanged) {
      await sleep(700); const nfp = await call('fp');
      rec.saltos.push({ idx: tested.indexOf(c), fp: nfp });
      rec.enlaces.internos.push({ destino: a.titulo ? 'Diapositiva con «' + a.titulo.slice(0, 40) + '»' : 'otra diapositiva', texto: lbl, via: 'clic en elemento' });
      if (!(await goTo(i))) { rec.notas.push('No se pudo volver a esta diapositiva tras probar un enlace; se detienen las pruebas en ella.'); break; }
      continue;
    }
    if (a.nuevosTextos.length || a.nuevasImagenes.length || a.dialogos) {
      const sg = a.nuevosTextos.join('|') + '#' + a.nuevasImagenes.join('|');
      if (seen.has(sg)) seen.get(sg).disparadores++;
      else {
        const p = { elemento: lbl, textos: a.nuevosTextos.slice(0, 4), imagenes: a.nuevasImagenes.map((u) => imgName({ url: u, alt: '' })), deteccion: a.dialogos ? 'clase de ventana/diálogo' : 'aparición de contenido nuevo', disparadores: 1 };
        seen.set(sg, p); rec.popups.push(p);
        a.nuevasImagenes.forEach((u) => rec.imagenes.enEmergentes.push({ nombre: imgName({ url: u, alt: '' }), url: u }));
      }
    } else rec.sinEfecto++;
    if (!(await closePopup(i, base))) {
      if (!(await goTo(i))) { rec.notas.push('No se pudo cerrar una ventana emergente; se detienen las pruebas en esta diapositiva.'); break; }
    }
  }
}

/* ================= Informe ================= */
const h = (t, a = {}, ...k) => {
  const e = document.createElement(t);
  for (const [x, v] of Object.entries(a)) {
    if (x === 'class') e.className = v;
    else if (/^on/.test(x) && typeof v === 'function') e[x] = v;
    else if (typeof v === 'boolean') { if (x === 'checked' || x === 'selected' || x === 'disabled') e[x] = v; if (v) e.setAttribute(x, ''); }
    else if (x === 'value') { e.value = v; e.setAttribute('value', v); }
    else e.setAttribute(x, v);
  }
  k.flat().forEach((c) => { if (c !== null && c !== undefined && c !== false) e.append(c instanceof Node ? c : document.createTextNode(String(c))); });
  return e;
};
const list = (items, empty) => items.length ? h('ul', {}, items.map((x) => h('li', {}, x))) : h('div', { class: 'muted' }, empty);

function totals() {
  const d = rep.diapositivas, t = { slides: d.length, imgs: 0, files: new Set(), int: 0, ext: 0, anim: 0, pop: 0, tipos: {} };
  d.forEach((s) => {
    t.imgs += s.imagenes.total; s.imagenes.lista.forEach((i) => t.files.add(i.url));
    t.int += s.enlaces.internos.length; t.ext += s.enlaces.externos.length; t.anim += s.animaciones.total; t.pop += s.popups.length;
    Object.entries(s.animaciones.tipos).forEach(([k, v]) => { t.tipos[k] = (t.tipos[k] || 0) + v; });
  });
  return t;
}

function render() {
  rep.diapositivas.sort((a, b) => a.n - b.n);
  const t = totals(), root = $('report'); root.replaceChildren();
  const share = {}; rep.diapositivas.forEach((s) => s.imagenes.lista.forEach((i) => { if (i.itemId) (share[i.itemId] = share[i.itemId] || new Set()).add(s.n); }));
  if (!rep.diapositivas.length && !rep.avisos.length) return;
  root.append(h('h2', {}, rep.modo === 'alumno' ? 'Informe del Genially del alumno' : 'Informe del Genially'), h('div', { class: 'muted' }, rep.url + ' · ' + rep.fecha));
  if (cmpModel && rep.modo === 'alumno') compareSection().forEach((x) => root.append(x));
  const card = (n, l) => h('div', { class: 'card' }, h('b', {}, n), h('span', {}, l));
  root.append(h('div', { class: 'cards' },
    card(t.slides + (rep.totalPaginas ? ' de ' + rep.totalPaginas : ''), 'diapositivas analizadas'), card(t.imgs, 'imágenes (' + t.files.size + ' archivos distintos)'),
    card(t.int, 'enlaces a otras páginas'), card(t.ext, 'enlaces externos'),
    card(t.anim, 'elementos animados'), card(t.pop, 'ventanas emergentes')));
  rep.avisos.forEach((a) => root.append(h('div', { class: 'warn' }, a)));
  if (Object.keys(t.tipos).length) root.append(h('p', {}, h('b', {}, 'Tipos de animación en todo el Genially: '), Object.entries(t.tipos).sort((a, b) => b[1] - a[1]).map(([k, v]) => h('span', { class: 'tag' }, k + ' ×' + v))));

  root.append(h('h2', {}, 'Resumen por diapositiva'));
  const th = (x, c) => h('th', c ? { class: c } : {}, x), td = (x, c) => h('td', c ? { class: c } : {}, x);
  root.append(h('table', {},
    h('tr', {}, th('Nº', 'n'), th('Título / primer texto'), th('Imágenes', 'n'), th('Enlaces a otras páginas', 'n'), th('Enlaces externos', 'n'), th('Animaciones (tipos)'), th('Ventanas emergentes', 'n')),
    rep.diapositivas.map((s) => h('tr', {},
      td(s.n, 'n'), td(s.titulo ? s.titulo.slice(0, 60) : '—'), td(s.imagenes.total + ((s.imagenes.fondos || []).length ? ' (+' + s.imagenes.fondos.length + ' fondo)' : ''), 'n'), td(s.enlaces.internos.length, 'n'), td(s.enlaces.externos.length, 'n'),
      td(s.animaciones.total + (s.animaciones.total ? ' (' + Object.keys(s.animaciones.tipos).join(', ') + ')' : '')), td(s.popups.length, 'n')))));

  root.append(h('h2', {}, 'Detalle de cada diapositiva'));
  rep.diapositivas.forEach((s) => {
    const sec = (x) => h('div', { class: 'sec' }, x);
    root.append(h('details', {},
      h('summary', {}, 'Diapositiva ' + s.n + (s.titulo ? ' — ' + s.titulo.slice(0, 70) : '')),
      sec('Elementos de Genially en la diapositiva: ' + s.elementos.length),
      list(Object.entries(s.elementos.reduce((o, e) => { const k = e.cy === 'textItemView' ? 'Texto' : e.cy === 'imageItemView' ? 'Imagen' : e.tipo; o[k] = (o[k] || 0) + 1; return o; }, {})).map(([k, v]) => k + ' ×' + v), 'Ninguno detectado.'),
      sec('Imágenes: ' + s.imagenes.total + ' (' + s.imagenes.distintas + ' distintas)'),
      list(s.imagenes.lista.map((i) => h('span', { title: i.url }, i.nombre, i.veces > 1 ? h('span', { class: 'tag' }, '×' + i.veces) : null, i.itemId && share[i.itemId] && share[i.itemId].size > 1 ? h('span', { class: 'tag' }, 'se repite en ' + share[i.itemId].size + ' diapositivas') : null)), 'Sin imágenes detectadas.'),
      (s.imagenes.fondos || []).length ? [sec('Imagen de fondo de la diapositiva: ' + s.imagenes.fondos.length), list(s.imagenes.fondos.map((i) => h('span', { title: i.url }, i.nombre)), '')] : null,
      s.imagenes.enEmergentes.length ? [sec('Imágenes que aparecen dentro de ventanas emergentes: ' + s.imagenes.enEmergentes.length), list(s.imagenes.enEmergentes.map((i) => i.nombre), '')] : null,
      sec('Enlaces a otras páginas: ' + s.enlaces.internos.length),
      list(s.enlaces.internos.map((l) => (l.destino || '') + (l.texto ? ' · ' + l.texto : '') + ' (' + l.via + ')'), 'Ninguno detectado.'),
      sec('Enlaces externos: ' + s.enlaces.externos.length),
      list(s.enlaces.externos.map((l) => l.href + (l.texto ? ' · ' + l.texto : '') + ' (' + l.via + ')'), 'Ninguno detectado.'),
      sec('Animaciones: ' + s.animaciones.total + (s.animaciones.infinitas ? ' (' + s.animaciones.infinitas + ' en bucle)' : '')),
      list(Object.entries(s.animaciones.tipos).map(([k, v]) => k + ' — ' + v + (v > 1 ? ' elementos' : ' elemento')), 'Ninguna detectada.'),
      sec('Ventanas emergentes: ' + s.popups.length + '  ' ),
      list(s.popups.map((p) => 'Se abre al pulsar «' + p.elemento + '»' + (p.textos.length ? ' · texto: ' + p.textos.join(' / ').slice(0, 140) : '') + (p.imagenes.length ? ' · imágenes: ' + p.imagenes.join(', ') : '') + ' [' + p.deteccion + ']'), 'Ninguna detectada.'),
      s.probados ? h('div', { class: 'muted' }, 'Elementos clicables probados: ' + s.probados + ' · sin efecto visible: ' + s.sinEfecto) : null,
      s.notas.map((n) => h('div', { class: 'warn' }, n))));
  });
  $('out').value = JSON.stringify(rep, null, 1);
  $('rawbox').style.display = ''; ['dl', 'dlh', 'copy'].forEach((b) => { $(b).disabled = !rep.diapositivas.length; });
}

/* ================= Proceso principal ================= */
$('go').onclick = async () => {
  const url = $('url').value.trim();
  if (!/^https?:\/\//.test(url)) return alert('Pega un enlace válido');
  $('go').disabled = true;
  rep.url = url; rep.fecha = new Date().toLocaleString('es-ES'); rep.diapositivas = []; rep.avisos = []; S.path = { 1: [] }; Object.keys(fps).forEach((k) => delete fps[k]);
  $('report').replaceChildren();
  let win, onTab;
  try {
    log('Abriendo el Genially…');
    win = await chrome.windows.create({ url, type: 'popup', width: 1280, height: 800, left: 40, top: 40, focused: true });
    S.tabId = win.tabs[0].id;
    onTab = (t) => { if (t.openerTabId === S.tabId) { S.newTabs.push({ url: t.pendingUrl || t.url || '' }); chrome.tabs.remove(t.id).catch(() => {}); } };
    chrome.tabs.onCreated.addListener(onTab);
    for (let i = 0; i < 40; i++) { await sleep(1000); try { const f = await call('frame'); if (f.containers) break; } catch (e) {} }
    try { await chrome.debugger.attach({ tabId: S.tabId }, '1.3'); S.dbg = true; } catch (e) { rep.avisos.push('No se pudo usar el depurador (' + e.message + '): se usan clics simulados, menos fiables.'); }
    await call('animStart'); await sleep(3000);

    const pages = await call('pages');
    const pageCount = pages.length ? Math.max(...pages.map((p) => p.n)) : 0;
    let fp = await call('fp'), i = 1;
    while (true) {
      log('Analizando la diapositiva ' + i + (pageCount ? ' de ' + pageCount : '') + '…');
      const an = await call('animStop');
      fps[i] = fp;
      const snap = await call('slide');
      const rec = buildSlide(i, snap, an);
      rep.diapositivas.push(rec); render();
      await testInteractions(i, rec, win);
      render();
      if (pageCount && i >= pageCount) break;
      if (i >= MAX_SLIDES) { rep.avisos.push('Se alcanzó el límite de ' + MAX_SLIDES + ' diapositivas.'); break; }
      if (!(await goTo(i))) { rep.avisos.push('Tras la diapositiva ' + i + ' no se pudo volver para avanzar; el análisis se detuvo.'); break; }
      await call('animStart');
      const adv = await advance(i, fps[i], rec);
      if (!adv) { rep.avisos.push('Tras la diapositiva ' + i + ' no se encontró forma de pasar a otra nueva (puede ser la última, o la navegación no se detectó).'); break; }
      const nf = adv.fp; S.path[i + 1] = (S.path[i] || []).concat(adv.step);
      if (Object.values(fps).some((f) => sim(nf, f) > 0.95)) { rep.avisos.push('La navegación volvió a una diapositiva ya analizada; se detiene el recorrido.'); break; }
      await sleep(1500); fp = nf; i++;
    }
    if (pageCount && pageCount !== rep.diapositivas.length) rep.avisos.push('La navegación indica ' + pageCount + ' páginas pero se analizaron ' + rep.diapositivas.length + '.');
    log('Listo. Puedes descargar el informe en .html o los datos en .json.');
  } catch (e) { rep.avisos.push('Error: ' + e.message); log('Error: ' + e.message); }
  finally {
    if (onTab) chrome.tabs.onCreated.removeListener(onTab);
    try { await chrome.debugger.detach({ tabId: S.tabId }); } catch (e) {}
    S.dbg = false;
    if (win) { try { await chrome.windows.remove(win.id); } catch (e) {} }
    render(); $('go').disabled = false;
  }
};


/* ================= MODO MANUAL: tú navegas, el programa observa y guarda ================= */
const M = { stop: false };
const lastClick = (col, maxAge) => { const c = (col.clicks || []).filter((x) => col.now - x.t < maxAge).pop(); return c || null; };
const itemKey = (it) => it.id || (it.tipo + '#' + it.texto);

function emptyRec(n) {
  return { n, titulo: '', textos: [], modoManual: true,
    imagenes: { total: 0, distintas: 0, lista: [], fondos: [], enEmergentes: [] },
    enlaces: { internos: [], externos: [] },
    animaciones: { total: 0, tipos: {}, infinitas: 0, detalle: [], debugClases: [] },
    popups: [], sinEfecto: 0, probados: 0, notas: [], saltos: [], elementos: [], fuentes: {}, colores: {}, textosTodos: [] };
}
function newSt() { return { fonts: {}, colors: {}, alltexts: new Set(), arrived: Date.now(), frozen: false, merged: 0, imgs: new Map(), items: new Map(), anim: new Map(), ext: new Set(), int: new Set(), lk: new Set(), base: null, cand: null, openSig: '' }; }

function mergeSnapshot(sl, col) {
  const { rec, st } = sl;
  if (col.titulo) rec.titulo = col.titulo;
  Object.entries(col.fonts || {}).forEach(([k, v]) => { st.fonts[k] = Math.max(st.fonts[k] || 0, v); }); rec.fuentes = { ...st.fonts };
  Object.entries(col.colors || {}).forEach(([k, v]) => { st.colors[k] = Math.max(st.colors[k] || 0, v); }); rec.colores = { ...st.colors };
  (col.alltexts || []).forEach((t) => st.alltexts.add(t)); rec.textosTodos = [...st.alltexts].slice(0, 150);
  rec.textos = col.texts;
  col.images.forEach((i) => { const k = (i.item || '') + '|' + i.url; if (!st.imgs.has(k)) st.imgs.set(k, { nombre: imgName(i), url: i.url, tipo: i.kind, itemId: i.item || '', veces: 1 }); });
  col.items.forEach((it) => { const k = itemKey(it); if (!st.items.has(k)) st.items.set(k, it); });
  col.anim.items.forEach((a) => st.anim.set(a.id + '|' + a.src, a));
  if (col.anim.debug.length) rec.animaciones.debugClases = col.anim.debug;
  col.links.ext.forEach((l) => { const k = l.href + '|' + l.texto; if (!st.ext.has(k)) { st.ext.add(k); rec.enlaces.externos.push(l); } });
  col.links.int.forEach((l) => { const k = (l.href || '') + '|' + l.texto; if (!st.int.has(k)) { st.int.add(k); rec.enlaces.internos.push(l); } });
  const all = [...st.imgs.values()], lista = all.filter((x) => x.tipo !== 'fondo');
  rec.imagenes.lista = lista; rec.imagenes.fondos = all.filter((x) => x.tipo === 'fondo');
  rec.imagenes.total = lista.length; rec.imagenes.distintas = new Set(lista.map((x) => x.url)).size;
  const els = new Set(), tipos = {}; let inf = 0;
  st.anim.forEach((a) => { els.add(a.id); (tipos[a.type] = tipos[a.type] || new Set()).add(a.id); if (a.infinite) inf++; });
  rec.animaciones.total = els.size; rec.animaciones.infinitas = inf; rec.animaciones.detalle = [...st.anim.values()].slice(0, 40);
  rec.animaciones.tipos = Object.fromEntries(Object.entries(tipos).map(([k, v]) => [k, v.size]));
  rec.elementos = [...st.items.values()].map((x) => ({ id: x.id, tipo: x.tipo, cy: x.cy }));
  st.merged++;
}

let lastModel = null, fileModel = null, cmpModel = null;

async function runSession(opts) {
  const url = opts.url, auto = !!opts.driver, quiet = !!opts.quiet, batch = !!opts.batch;
  if (!/^https?:\/\//.test(url)) { if (batch) throw new Error('Enlace no válido'); return alert('Pega un enlace válido'); }
  if (!batch) { lockUi(true); $('stopm').disabled = false; }
  M.stop = false;
  rep.url = url; rep.fecha = new Date().toLocaleString('es-ES'); rep.diapositivas = []; rep.totalPaginas = 0; rep.ruta = []; rep.modo = auto ? 'alumno' : 'manual'; delete rep.comparacion;
  rep.avisos = [auto ? 'Recorrido automático: se repiten los mismos clics del modelo, buscando cada elemento por su tipo y posición.' : 'Modo manual: el informe solo incluye las diapositivas que has visitado y los elementos que has activado.'];
  cmpModel = auto ? opts.model : null;
  $('report').replaceChildren();
  let win, onTab, driverP, loaded = false; const slides = {}; let cur = null, warnedNoPage = false; const pendingExt = [];
  const shot = async (page) => {      // miniatura de la diapositiva (sin ventana emergente abierta), vía depurador
    if (!S.dbg) return; const sl = slides[page]; if (!sl || sl.rec.captura) return;
    try {
      const lm = await send('Page.getLayoutMetrics'), vp = lm.cssVisualViewport || lm.visualViewport;
      const sc = Math.min(1, 480 / vp.clientWidth);
      const r = await send('Page.captureScreenshot', { format: 'jpeg', quality: 55, clip: { x: vp.pageX || 0, y: vp.pageY || 0, width: vp.clientWidth, height: vp.clientHeight, scale: sc } });
      if (r && r.data) sl.rec.captura = 'data:image/jpeg;base64,' + r.data;
    } catch (e) {}
  };
  const ctx = { shot, total: () => rep.totalPaginas, mute: false, hidden: false, cur: () => cur, slide: (n) => slides[n], warn: (m) => { if (!rep.avisos.includes(m)) rep.avisos.push(m); } };
  const getSlide = (n) => { if (!slides[n]) { slides[n] = { rec: emptyRec(n), st: newSt() }; rep.diapositivas.push(slides[n].rec); } return slides[n]; };
  try {
    log('Abriendo el Genially… (espera a que cargue)');
    win = await chrome.windows.create(quiet ? { url, type: 'popup', width: 980, height: 612, left: 20, top: 20, focused: false } : { url, type: 'popup', width: 1280, height: 800, left: 40, top: 40, focused: true });
    S.tabId = win.tabs[0].id;
    onTab = (t) => { if (t.openerTabId === S.tabId) { pendingExt.push({ url: t.pendingUrl || t.url || '' }); chrome.tabs.remove(t.id).catch(() => {}); if (!quiet) chrome.windows.update(win.id, { focused: true }).catch(() => {}); } };
    chrome.tabs.onCreated.addListener(onTab);
    for (let i = 0; i < 60 && !loaded; i++) { await sleep(1000); try { const f = await call('frame'); if (f.containers) loaded = true; } catch (e) {} }
    if (!loaded) { rep.avisos.push('No se pudo cargar la presentación (enlace incorrecto, privado o sin conexión).'); M.stop = true; }
    if (loaded) { try { const au = await call('author'); if (au) rep.autor = au; } catch (e) {} }
    if (auto && loaded) {
      try { await chrome.debugger.attach({ tabId: S.tabId }, '1.3'); S.dbg = true; try { await chrome.debugger.sendCommand({ tabId: S.tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: true }); } catch (e) {} } catch (e) { ctx.warn('No se pudo usar el depurador (' + e.message + '): los clics son simulados y pueden fallar.'); }
      driverP = opts.driver(ctx).catch((e) => ctx.warn('Error en el recorrido automático: ' + e.message)).then(() => { M.stop = true; });
    }
    while (!M.stop) {
      await sleep(600);
      try { await chrome.tabs.get(S.tabId); } catch (e) { rep.avisos.push('Se cerró la ventana del Genially.'); break; }
      let col; try { await call('ensure'); col = await call('collect'); } catch (e) { continue; }
      if (!col) continue;
      ctx.hidden = col.vis === 'hidden';
      if (ctx.hidden) { log('⏸ La ventana de Genially está minimizada o tapada del todo: Chrome detiene las animaciones. Muéstrala (aunque sea pequeña) y continúa sola.'); continue; }
      const now = Date.now();
      if (col.page) rep.totalPaginas = col.page.m;
      else if (!warnedNoPage && cur !== null && !ctx.mute) { warnedNoPage = true; rep.avisos.push('No se pudo leer el número de página de Genially: todo se agrupa en una sola diapositiva.'); }
      const key = col.page ? col.page.n : (cur || 1);

      if (key !== cur) {            // ---- cambio de diapositiva
        const click = lastClick(col, 8000);
        if (cur !== null && !ctx.mute) {
          const from = slides[cur].rec;
          if (click && click.inSlide) {
            const k = (click.itemId || click.name) + '>' + key;
            if (!slides[cur].st.lk.has(k)) {
              slides[cur].st.lk.add(k);
              from.enlaces.internos.push({ destino: 'Diapositiva ' + key, texto: click.name, via: auto ? 'clic (recorrido automático)' : 'clic (modo manual)' });
              if (click.pos) rep.ruta.push({ desde: cur, hacia: key, nombre: click.name, click: click.pos });
            }
          } else if (!click) {
            const nt = 'Se pasó a otra diapositiva sin pulsar un elemento (teclas o menú de navegación).';
            if (!from.notas.includes(nt)) from.notas.push(nt);
          }
        }
        cur = key; const sl = getSlide(key); sl.st.arrived = now; sl.st.cand = null; sl.st.openSig = '';
        render(); continue;
      }

      const sl = slides[cur] || getSlide(key), st = sl.st;
      const clickedSince = (col.clicks || []).some((c) => c.t >= st.arrived);
      if (!st.frozen) {
        if (now - st.arrived > 1500 && !clickedSince) mergeSnapshot(sl, col);
        if (clickedSince || now - st.arrived > 9000) {
          st.frozen = true; st.base = new Set(st.items.keys());
          if (!st.merged) sl.rec.notas.push('Se pulsó antes de que la diapositiva cargase del todo: los datos pueden estar incompletos.');
        }
      }
      while (pendingExt.length) { const p = pendingExt.shift(), c = lastClick(col, 8000); sl.rec.enlaces.externos.push({ href: p.url || '(se abre otra pestaña)', texto: c ? c.name : '', via: 'clic (abre pestaña)' }); if (c && c.pos && !auto) rep.ruta.push({ desde: cur, hacia: 'externo', nombre: c.name, click: c.pos }); }

      // ---- ventanas emergentes: elementos que pasan a verse tras un clic, sin cambiar de diapositiva
      if (st.frozen && st.base && st.base.size && !ctx.mute) {
        const keys = new Set(col.items.map(itemKey)), nuevos = col.items.filter((it) => !st.base.has(itemKey(it)));
        const lost = [...st.base].filter((k) => !keys.has(k)).length / st.base.size;
        const c = lastClick(col, 6000);
        if (nuevos.length && c && c.t >= st.arrived && lost < 0.5) {
          const sg = nuevos.map(itemKey).sort().join(',');
          if (!st.cand || st.cand.sg !== sg) st.cand = { sg, since: now };
          else if (now - st.cand.since > 1200 && sg !== st.openSig) {
            st.openSig = sg;
            const ex = sl.rec.popups.find((p) => p._sg === sg);
            if (ex) ex.disparadores++;
            else {
              const imgsU = [...new Set(nuevos.filter((x) => x.cy === 'imageItemView').flatMap((x) => x.imgs))];
              const p = { elemento: c.name, textos: nuevos.filter((x) => x.cy === 'textItemView' && x.texto).map((x) => x.texto).slice(0, 4), imagenes: imgsU.map((u) => imgName({ url: u, alt: '' })), deteccion: 'elementos que aparecen tras un clic', disparadores: 1 };
              Object.defineProperty(p, '_sg', { value: sg, enumerable: false }); sl.rec.popups.push(p);
              if (c.pos) rep.ruta.push({ desde: cur, hacia: null, nombre: c.name, click: c.pos });
              imgsU.forEach((u) => sl.rec.imagenes.enEmergentes.push({ nombre: imgName({ url: u, alt: '' }), url: u }));
            }
          }
        } else if (!nuevos.length) { st.cand = null; st.openSig = ''; }
        else if (lost >= 0.5) st.cand = null;
      }
      const t = totals();
      log((auto ? 'Recorrido automático' : 'Modo manual') + ' · diapositiva actual: ' + cur + (rep.totalPaginas ? ' de ' + rep.totalPaginas : '') + ' · vistas: ' + t.slides + ' · imágenes ' + t.imgs + ' · enlaces internos ' + t.int + ' · animaciones ' + t.anim + ' · ventanas emergentes ' + t.pop + (auto ? ' — no toques la ventana.' : ' — navega y pulsa «Terminar» cuando acabes.'));
    }
    if (driverP) await driverP;
    const vistas = rep.diapositivas.map((d) => d.n);
    if (rep.totalPaginas && vistas.length < rep.totalPaginas) {
      const falta = []; for (let n = 1; n <= rep.totalPaginas; n++) if (!vistas.includes(n)) falta.push(n);
      rep.avisos.push(auto ? 'La presentación tiene ' + rep.totalPaginas + ' diapositivas y el recorrido solo llegó a ' + vistas.length + '. No alcanzadas (nº de página del alumno): ' + falta.join(', ') + '.' : 'El Genially tiene ' + rep.totalPaginas + ' diapositivas y se han visitado ' + vistas.length + '. No visitadas: ' + falta.join(', ') + '.');
    }
    log(auto ? 'Recorrido terminado: informe y comparación listos.' : 'Informe generado a partir de ' + rep.diapositivas.length + ' diapositivas visitadas.');
  } catch (e) { rep.avisos.push('Error: ' + e.message); log('Error: ' + e.message); }
  finally {
    if (onTab) chrome.tabs.onCreated.removeListener(onTab);
    if (S.dbg) { try { await chrome.debugger.detach({ tabId: S.tabId }); } catch (e) {} S.dbg = false; }
    if (win) { try { await chrome.windows.remove(win.id); } catch (e) {} }
    if (!auto && rep.ruta.length) { lastModel = JSON.parse(JSON.stringify(rep)); fileModel = null; saveState(); renderModelInfo(); }
    if (auto && cmpModel) rep.comparacion = compareReports(cmpModel, rep).map((r) => ({ n: r.n, titulo: r.titulo, alcanzada: !!r.b, diferencias: r.diffs }));
    render(); if (!batch) { lockUi(false); $('stopm').disabled = true; }
  }
  return { ok: loaded && rep.diapositivas.length > 0 };
}

/* ---------- Parecido entre diapositivas (por su texto, no por su número) ---------- */
const normTxt = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const wordsOf = (r) => new Set(normTxt([r.titulo, ...(r.textos || [])].join(' ')).match(/[a-z0-9]{3,}/g) || []);
function slideSim(a, b) {
  const A = wordsOf(a), B = wordsOf(b); if (!A.size || !B.size) return 0;
  let i = 0; A.forEach((x) => { if (B.has(x)) i++; });
  return i / (A.size + B.size - i) + (a.titulo && normTxt(a.titulo) === normTxt(b.titulo) ? 0.5 : 0);
}
const SIM_MIN = 0.35;
function matchSlides(ms, ss) {          // devuelve Map: nº de diapositiva del modelo -> diapositiva del alumno
  const pairs = []; ms.forEach((a) => ss.forEach((b) => pairs.push([slideSim(a, b), a, b])));
  pairs.sort((x, y) => y[0] - x[0]);
  const ua = new Set(), ub = new Set(), map = new Map();
  for (const [sc, a, b] of pairs) { if (sc < SIM_MIN) break; if (ua.has(a.n) || ub.has(b.n)) continue; ua.add(a.n); ub.add(b.n); map.set(a.n, b); }
  return map;
}

/* ---------- Recorrido automático del alumno: repite la ruta grabada en el modelo ---------- */
// Las diapositivas se identifican por su contenido: el alumno puede tenerlas en otro orden que el profesor.
async function studentDriver(ctx, model) {
  const by = {}; (model.ruta || []).forEach((s) => { (by[s.desde] = by[s.desde] || []).push(s); });
  const mSlides = {}; model.diapositivas.forEach((d) => { mSlides[d.n] = d; });
  const isLink = (s) => typeof s.hacia === 'number';
  const mOfPage = {};                       // página del alumno -> diapositiva del modelo
  const identify = (page) => {
    if (page in mOfPage) return mOfPage[page];
    const rec = ctx.slide(page) && ctx.slide(page).rec; if (!rec || !(rec.titulo || (rec.textos || []).length)) return null;
    let best = null, bs = 0;
    model.diapositivas.forEach((d) => { const sc = slideSim(d, rec); if (sc > bs) { bs = sc; best = d.n; } });
    return (mOfPage[page] = bs >= SIM_MIN ? best : null);
  };
  const ttl = (m) => (mSlides[m] && mSlides[m].titulo ? '«' + mSlides[m].titulo.slice(0, 30) + '»' : 'la diapositiva ' + m);
  const wait = async (cond, ms) => { let t0 = Date.now(); while (Date.now() - t0 < ms && !M.stop) { if (ctx.hidden) { const z = Date.now(); await sleep(700); t0 += Date.now() - z; continue; } if (await cond()) return true; await sleep(250); } return !!(await cond()); };
  const settle = async (page, ms) => {
    if (!(await wait(() => ctx.cur() === page, 6000))) return false;
    const sl = ctx.slide(page); await wait(() => Date.now() - sl.st.arrived > (ms || 3600), 6000); return true;
  };
  // Pulsa un paso del modelo esperando a que el elemento exista, sea pulsable (no tapado ni en animación) y la página esté quieta
  const clickStep = async (s) => {
    let w = null, t0 = Date.now();
    for (let k = 0; k < 20 && !M.stop; k++) {
      if (ctx.hidden) { const z = Date.now(); await sleep(700); t0 += Date.now() - z; k--; continue; }
      w = await call('where', s.click);
      const q = await call('quiet'), el = Date.now() - t0;
      if (w.found && w.hit && ((q.quiet >= 700 && q.running === 0) || el > 4000)) break;
      if (el > 9000) break;
      await sleep(500);
    }
    if (S.dbg) await mouse(w.x, w.y); else await call('clickAt', { x: w.x, y: w.y });
    return w;
  };
  const how = (w) => w.found ? (w.hit ? 'elemento encontrado' : 'elemento encontrado pero no pulsable: tapado o sin interacción') : 'elemento no encontrado; se pulsó por posición';
  const pathTo = (from, to) => {
    const q = [[from, []]], seen = new Set([from]);
    while (q.length) {
      const [c, p] = q.shift(); if (c === to) return p;
      (by[c] || []).filter(isLink).forEach((s) => { if (!seen.has(s.hacia)) { seen.add(s.hacia); q.push([s.hacia, p.concat(s)]); } });
    }
    return null;
  };
  const replayTo = async (page) => {        // recarga el Genially y repite la ruta del modelo hasta la página del alumno indicada
    const p = pathTo(identify(1), identify(page)); if (!p) return false;
    ctx.mute = true;
    try {
      await chrome.tabs.reload(S.tabId); await waitSlides(); await sleep(3500);
      for (const s of p) { await clickStep(s); await sleep(2200); }
      return await wait(() => ctx.cur() === page, 5000);
    } finally { await sleep(1500); ctx.mute = false; }
  };
  const isOpen = async (page) => { const base = ctx.slide(page).st.base; const c = await call('collect'); return !!base && c.items.some((it) => !base.has(itemKey(it))); };
  const closePopup = async (page, trig) => {
    if (!(await isOpen(page))) return true;
    await key('Escape', 27); await sleep(900); if (!(await isOpen(page))) return true;
    await clickStep(trig); await sleep(900); return !(await isOpen(page));
  };
  // Cambia de página con las flechas laterales de Genially (o el teclado, o los botones «Ir a la página N») hasta llegar a la página p
  let arrowFails = 0;
  const gotoByArrows = async (p) => {
    if (arrowFails >= 2) return false;       // si ya fallaron dos veces seguidas, es que esta presentación no tiene forma de pasar de página
    for (let guard = 0; guard < 60 && !M.stop && ctx.cur() !== p; guard++) {
      const cur = ctx.cur(), dir = p > cur ? 'next' : 'prev', from = cur;
      const methods = [
        async () => { const a = await call('arrow', dir); if (!a) return false; await clickRec(a); return true; },
        async () => { await key(dir === 'next' ? 'ArrowRight' : 'ArrowLeft', dir === 'next' ? 39 : 37); return true; },
        async () => { const b = (await call('pages')).find((x) => x.n === p); if (!b) return false; await clickRec(b); return true; }
      ];
      let moved = false;
      ctx.mute = true;
      try {
        for (const m of methods) { if (!(await m())) continue; if (await wait(() => ctx.cur() !== from, 3500)) { moved = true; break; } }
        if (moved) await sleep(900);
      } finally { ctx.mute = false; }
      if (!moved) { arrowFails++; return false; }
      arrowFails = 0;
    }
    return ctx.cur() === p;
  };
  // vuelve de una página del alumno a otra usando el enlace del modelo; si falla, recarga y repite la ruta
  const back = async (from, to) => {
    const b = (by[identify(from)] || []).find((s) => s.hacia === identify(to));
    if (b) {
      const w = await clickStep(b);
      if (await wait(() => ctx.cur() === to, 4500)) return true;
      const nt = 'El enlace «' + b.nombre + '» (hacia ' + ttl(b.hacia) + ') no lleva a ninguna parte (' + how(w) + '); se continuó con otro método.';
      if (!ctx.slide(from).rec.notas.some((x) => x.startsWith('El enlace «' + b.nombre + '»'))) ctx.slide(from).rec.notas.push(nt);
    }
    if (await gotoByArrows(to)) return true;
    return replayTo(to);
  };
  const visited = new Set();
  // Al terminar, el navegador queda en la página "page" (salvo en la raíz, que no necesita volver a ningún sitio)
  async function visit(page, parent) {
    if (visited.has(page) || M.stop) return; visited.add(page);
    if (!(await settle(page))) { ctx.warn('No se pudo llegar a la página ' + page + ' del alumno.'); return; }
    if (ctx.shot && !ctx.mute) await ctx.shot(page);
    const rec = ctx.slide(page).rec, m = identify(page);
    if (m == null) { rec.notas.push('Esta diapositiva no se parece a ninguna del modelo, así que no se pueden repetir sus clics.'); return; }
    const mParent = parent == null ? null : identify(parent), steps = by[m] || [];
    const todo = [...steps.filter((s) => s.hacia == null), ...steps.filter((s) => s.hacia === 'externo'), ...steps.filter((s) => isLink(s) && s.hacia !== mParent)];
    for (let idx = 0; idx < todo.length; idx++) {
      const s = todo[idx], last = idx === todo.length - 1, pops = () => rec.popups.reduce((t, p) => t + p.disparadores, 0);
      if (M.stop) return;
      if (s.hacia == null) {                                    // ventana emergente del modelo
        const before = pops();
        let w = await clickStep(s); await sleep(3000);
        if (pops() === before && !(await isOpen(page))) { w = await clickStep(s); await sleep(3000); }   // clic perdido: un reintento
        if (pops() === before) rec.notas.push('No se abrió la ventana emergente que el modelo abre al pulsar «' + s.nombre + '» (' + how(w) + ')' + ((await isOpen(page)) ? '; aparece contenido nuevo pero no se pudo registrar como ventana' : '') + '.');
        if (!(await closePopup(page, s))) {
          if (!(await replayTo(page))) { ctx.warn('No se pudo cerrar una ventana emergente en la página ' + page + ' del alumno; se detiene el recorrido.'); return; }
          await settle(page, 2200);
        }
      } else if (s.hacia === 'externo') {                       // enlace que abre otra pestaña (la extensión la cierra sola)
        await clickStep(s); await sleep(2500);
      } else {                                                  // enlace a otra diapositiva
        const w = await clickStep(s);
        await wait(() => ctx.cur() !== page, 4500);
        const dest = ctx.cur();
        if (dest === page) { rec.notas.push('El enlace «' + s.nombre + '» (hacia ' + ttl(s.hacia) + ') no lleva a ninguna parte (' + how(w) + ').'); continue; }
        await settle(dest, visited.has(dest) ? 2200 : 3600);
        const md = identify(dest);
        if (md !== s.hacia) rec.notas.push('El enlace «' + s.nombre + '» lleva a ' + (md == null ? 'una diapositiva que no está en el modelo' : ttl(md)) + ' y en el modelo lleva a ' + ttl(s.hacia) + '.');
        await visit(dest, page);
        if (M.stop) return;
        if (last && parent == null) return;
        if (!(await back(dest, page))) { ctx.warn('No se pudo volver a la página ' + page + ' desde la ' + dest + '; el recorrido se detiene.'); return; }
        await settle(page, 2200);
      }
    }
  }
  await visit(1, null);

  // Páginas a las que no se llegó por enlaces (p. ej. porque el alumno no los puso): se intenta pasar con las flechas laterales
  const total = ctx.total ? ctx.total() : 0;
  for (let p = 1; total && p <= total && !M.stop; p++) {
    if (visited.has(p)) continue;
    if (!(await gotoByArrows(p))) { ctx.warn('La página ' + p + ' del alumno no se pudo alcanzar ni con enlaces ni con las flechas de navegación.'); continue; }
    const sl = ctx.slide(p); if (sl && !sl.rec.notas.some((x) => /^Sin enlace/.test(x))) sl.rec.notas.push('Sin enlace: a esta diapositiva no lleva ningún enlace de la presentación; se alcanzó con las flechas de navegación.');
    await visit(p, null);
  }
}

/* ---------- Comparación modelo / alumno ---------- */
function compareReports(m, st) {
  const map = matchSlides(m.diapositivas, st.diapositivas), s2m = {}; map.forEach((b, mn) => { s2m[b.n] = mn; });
  const tr = (d) => { const x = /(\d+)/.exec(d || ''), n = x && s2m[+x[1]]; return n ? 'Diapositiva ' + n : d + ' (sin equivalente en el modelo)'; };
  const rows = m.diapositivas.slice().sort((a, b) => a.n - b.n).map((a) => {
    const b = map.get(a.n), diffs = [];
    if (!b) return { n: a.n, titulo: a.titulo, a, b: null, diffs: ['No se pudo llegar a esta diapositiva siguiendo la ruta del modelo.'] };
    const cmp = (l, x, y) => { if (x !== y) diffs.push(l + ': modelo ' + x + ', alumno ' + y); };
    cmp('Imágenes', a.imagenes.total, b.imagenes.total);
    cmp('Elementos animados', a.animaciones.total, b.animaciones.total);
    new Set([...Object.keys(a.animaciones.tipos), ...Object.keys(b.animaciones.tipos)]).forEach((k) => cmp('Animación «' + k + '»', a.animaciones.tipos[k] || 0, b.animaciones.tipos[k] || 0));
    const dm = new Set(a.enlaces.internos.map((l) => l.destino)), ds = new Set(b.enlaces.internos.map((l) => tr(l.destino)));
    const falta = [...dm].filter((x) => !ds.has(x)), sobra = [...ds].filter((x) => !dm.has(x));
    if (falta.length) diffs.push('Enlaces del modelo que no funcionan o faltan (destino): ' + falta.join(', ') + '.');
    if (sobra.length) diffs.push('Enlaces que el modelo no tiene (destino): ' + sobra.join(', ') + '.');
    cmp('Enlaces externos', a.enlaces.externos.length, b.enlaces.externos.length);
    cmp('Ventanas emergentes', a.popups.length, b.popups.length);
    b.notas.forEach((x) => { if (/^(El enlace|No se abrió|Esta diapositiva no se parece|Sin enlace)/.test(x)) diffs.push(x); });
    return { n: a.n, titulo: a.titulo, a, b, diffs };
  });
  rows.s2m = s2m; rows.tr = tr;
  rows.extras = st.diapositivas.filter((b) => !Object.prototype.hasOwnProperty.call(s2m, b.n)).map((b) => b.n);
  return rows;
}
function mkCard(n, l) { return h('div', { class: 'card' }, h('b', {}, n), h('span', {}, l)); }
function compareSection() {
  const rows = compareReports(cmpModel, rep), ok = rows.filter((r) => !r.diffs.length).length;
  const cell = (x, y, bad) => h('td', { class: 'n' + (bad ? ' diff' : '') }, x + ' / ' + y);
  const out = [h('h2', {}, 'Comparación con el modelo'),
    h('div', { class: 'cards' }, mkCard(ok + ' de ' + rows.length, 'diapositivas iguales al modelo'), mkCard(rows.filter((r) => !r.b).length, 'no alcanzadas'), mkCard(rows.reduce((t, r) => t + r.diffs.length, 0), 'diferencias detectadas')),
    h('p', { class: 'muted' }, 'Las diapositivas se emparejan por su contenido (texto), no por su número de página. Cada celda muestra «modelo / alumno». En rojo, lo que no coincide.'),
    h('table', {}, h('tr', {}, ['Nº modelo', 'Diapositiva', 'Imágenes', 'Animaciones', 'Enlaces a otras páginas', 'Ventanas emergentes', 'Estado'].map((x, i) => h('th', i === 0 ? { class: 'n' } : {}, x))),
      rows.map((r) => { const a = r.a, b = r.b; const g = (f) => (b ? cell(f(a), f(b), f(a) !== f(b)) : cell(f(a), '—', true)); return h('tr', {}, h('td', { class: 'n' }, r.n + (b && b.n !== r.n ? ' (alumno: ' + b.n + ')' : '')), h('td', {}, r.titulo ? r.titulo.slice(0, 40) : '—'), g((x) => x.imagenes.total), g((x) => x.animaciones.total), g((x) => x.enlaces.internos.length), g((x) => x.popups.length), h('td', {}, r.diffs.length ? r.diffs.length + ' diferencia(s)' : 'igual')); }))];
  if (rows.extras.length) out.push(h('div', { class: 'warn' }, 'Páginas del alumno visitadas que no se parecen a ninguna del modelo: ' + rows.extras.join(', ') + '.'));
  rows.filter((r) => r.diffs.length).forEach((r) => out.push(h('details', {}, h('summary', {}, 'Diapositiva ' + r.n + (r.titulo ? ' — ' + r.titulo.slice(0, 50) : '') + ' · ' + r.diffs.length + ' diferencia(s)'), list(r.diffs, ''))));
  return out;
}

$('manual').onclick = () => runSession({ url: $('url').value.trim() });
$('alumno').onclick = () => {
  const model = fileModel || lastModel;
  if (!model || !model.ruta || !model.ruta.length) return alert('Falta el modelo. Graba primero la presentación del profesor en modo manual (con esta versión), o carga un informe .json de modelo guardado con esta versión.');
  runSession({ url: $('url2').value.trim(), model, driver: (ctx) => studentDriver(ctx, model) });
};
$('mfile').onchange = async (ev) => {
  const f = ev.target.files[0]; if (!f) return;
  try {
    const j = JSON.parse(await f.text());
    if (!j.diapositivas || !j.diapositivas.length) throw new Error('no parece un informe de Genially');
    if (!j.ruta || !j.ruta.length) throw new Error('este informe se guardó sin la ruta de clics; vuelve a grabar el modelo en modo manual con esta versión');
    fileModel = j; lastModel = null; saveState(); renderModelInfo();
  } catch (e) { ev.target.value = ''; alert('No se pudo usar ese modelo: ' + e.message); }
};
$('stopm').onclick = () => { M.stop = true; };

const save = (name, type, content) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type })); a.download = name; a.click(); };
$('dl').onclick = () => save(rep.modo === 'alumno' ? 'informe-genially-alumno.json' : 'informe-genially.json', 'application/json', $('out').value);
$('dlh').onclick = () => save('informe-genially.html', 'text/html', '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>Informe de Genially</title><style>' + document.querySelector('style').textContent + '</style></head><body>' + $('report').outerHTML + '</body></html>');
$('copy').onclick = () => { $('out').select(); document.execCommand('copy'); log('Datos copiados'); };
