const PANEL = () => chrome.runtime.getURL('analizador.html');

chrome.action.onClicked.addListener(async () => {
  const url = PANEL();
  const tabs = (await chrome.tabs.query({})).filter((t) => t.url === url);
  if (tabs.length) { await chrome.tabs.update(tabs[0].id, { active: true }); await chrome.windows.update(tabs[0].windowId, { focused: true }); }
  else await chrome.tabs.create({ url });
});

/* ---------- Conexión con el Cuaderno de Evaluación ---------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.tipo === 'abrir-corrector') { abrirCorrector(msg.payload, sender.tab).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message })); return true; }
  if (msg.tipo === 'enviar-notas') { enviarNotas(msg).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message })); return true; }
});

// El cuaderno pide abrir el corrector para un apartado: se guardan los datos y se abre (o se enfoca) su pestaña
async function abrirCorrector(p, tab) {
  if (!p || !p.sesion || !Array.isArray(p.alumnos)) throw new Error('Faltan datos del apartado.');
  const key = 'sesion:' + p.sesion;
  await chrome.storage.local.set({ [key]: { ...p, tabCuaderno: tab ? tab.id : null, recibido: Date.now() } });
  const url = PANEL() + '?sesion=' + encodeURIComponent(p.sesion);
  const abierta = (await chrome.tabs.query({})).find((t) => t.url === url);
  if (abierta) {
    await chrome.tabs.update(abierta.id, { active: true });
    await chrome.windows.update(abierta.windowId, { focused: true });
    chrome.runtime.sendMessage({ tipo: 'sesion-actualizada', sesion: p.sesion }).catch(() => {});
  } else {
    await chrome.tabs.create(tab ? { url, windowId: tab.windowId, index: tab.index + 1 } : { url });
  }
  return { ok: true };
}

// El corrector manda las notas: se entregan a la pestaña del cuaderno (o a cualquier cuaderno abierto que tenga ese apartado)
async function enviarNotas(msg) {
  const key = 'sesion:' + msg.sesion, s = (await chrome.storage.local.get(key))[key];
  const intenta = async (id) => { try { return await chrome.tabs.sendMessage(id, { tipo: 'notas-genially', datos: msg.datos }); } catch (e) { return null; } };
  let ultimoError = '';
  if (s && s.tabCuaderno != null) { const r = await intenta(s.tabCuaderno); if (r && r.ok) return r; if (r) ultimoError = r.error; }
  const tabs = (await chrome.tabs.query({})).filter((t) => t.id !== (s && s.tabCuaderno) && /^(https?|file):/.test(t.url || ''));
  for (const t of tabs) {
    const r = await intenta(t.id);
    if (r && r.ok) { if (s) { s.tabCuaderno = t.id; await chrome.storage.local.set({ [key]: s }); } return r; }
    if (r && r.error && r.error !== 'no es el cuaderno') ultimoError = r.error;
  }
  return { ok: false, error: ultimoError || 'el cuaderno no está abierto' };
}
