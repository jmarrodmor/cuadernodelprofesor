/* ===== Evaluador: varios alumnos, criterios con importancia, notas ===== */
const lsGet = (k, d) => { try { if (typeof localStorage === 'undefined') return d; const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
// Si el corrector se abre desde el Cuaderno de Evaluación, trabaja en una «sesión» propia de ese apartado
const SESION = (() => { try { return new URLSearchParams(location.search).get('sesion') || ''; } catch (e) { return ''; } })();
const KP = SESION ? 'gen.s.' + SESION + '.' : 'gen.';
function capKey(a) { return (SESION ? 's' + SESION + ':' : '') + 'c' + a.id; }
const lsSet = (k, v) => { try { if (typeof localStorage !== 'undefined') localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

const CRITERIOS = [
  { id: 'img', nombre: 'Número de imágenes', ayuda: 'Solo si la diapositiva del profesor tiene imágenes. Tener más no penaliza.', w: 3 },
  { id: 'animN', nombre: 'Elementos animados', ayuda: 'Solo si la del profesor tiene animaciones. Tener más no penaliza.', w: 2 },
  { id: 'animT', nombre: 'Tipos de animación', ayuda: 'Fundido, zoom, giro, desplazamiento… Cuenta los tipos del profesor que aparecen en el alumno.', w: 2 },
  { id: 'enl', nombre: 'Enlaces a otras páginas', ayuda: 'Cada enlace del profesor debe llevar al mismo destino.', w: 4 },
  { id: 'ext', nombre: 'Enlaces externos', ayuda: 'Solo si la del profesor tiene.', w: 1 },
  { id: 'pop', nombre: 'Ventanas emergentes', ayuda: 'Solo si la del profesor tiene (si no, ni se buscan).', w: 4 },
  { id: 'font', nombre: 'Fuente de la letra', ayuda: 'Requiere grabar el modelo con esta versión.', w: 2 },
  { id: 'color', nombre: 'Color de la letra', ayuda: 'Requiere grabar el modelo con esta versión. Se compara el color exacto.', w: 2 },
  { id: 'texto', nombre: 'Coincidencia de los textos', ayuda: 'Porcentaje de las palabras del texto del profesor que aparecen en la diapositiva del alumno.', w: 3 },
];
const defaultCrit = () => { const c = { zeroUnreached: true }; CRITERIOS.forEach((k) => { c[k.id] = { on: true, w: k.w }; }); return c; };
let crit = Object.assign(defaultCrit(), lsGet(KP + 'crit', {}));
CRITERIOS.forEach((k) => { if (!crit[k.id]) crit[k.id] = { on: true, w: k.w }; });
let extras = lsGet(KP + 'extras', []);   // apartados manuales: {id, nombre, on, w}
let alumnos = lsGet(KP + 'alumnos', []);
const activos = () => [...CRITERIOS.filter((k) => crit[k.id] && crit[k.id].on), ...extras.filter((e) => e.on).map((e) => ({ id: e.id, nombre: e.nombre || 'Apartado', w: e.w, manual: true }))];
alumnos.forEach((a) => { if (a.estado === 'en curso' || a.estado === 'en cola') a.estado = 'pendiente'; });
// miniaturas: se guardan aparte (IndexedDB) porque ocupan mucho
const idb = (() => {
  let p; const open = () => p || (p = new Promise((res, rej) => { try { const r = indexedDB.open('gen-eval', 1); r.onupgradeneeded = () => r.result.createObjectStore('caps'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); } catch (e) { rej(e); } }));
  const tx = async (mode, f) => { const d = await open(); return new Promise((res, rej) => { const t = d.transaction('caps', mode), q = f(t.objectStore('caps')); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); }); };
  return { get: (k) => tx('readonly', (s) => s.get(k)).catch(() => undefined), set: (k, v) => tx('readwrite', (s) => (v == null ? s.delete(k) : s.put(v, k))).catch(() => {}) };
})();
let full = {};                 // informes completos de esta sesión (id -> rep)
const B = { running: false, cancel: false, kind: '', queue: [], done: 0, total: 0 };
let uid = alumnos.reduce((m, a) => Math.max(m, a.id || 0), 0);

const getModel = () => fileModel || lastModel;
function saveState(sync) {
  lsSet(KP + 'ts', Date.now()); if (SESION && sync !== false) programarEnvio();
  lsSet(KP + 'crit', crit); lsSet(KP + 'extras', extras); if ($('pname')) lsSet(KP + 'nombre', $('pname').value);
  lsSet(KP + 'alumnos', alumnos.map((a) => { const { caps, ...r } = a; return r; }));
  const m = getModel(); if (m) lsSet(KP + 'modelo', m);
}
function renderModelInfo() {
  const m = getModel(), el = $('minfo'), box = $('modelbox');
  if (!el) return;
  if (!m) { el.textContent = 'Sin modelo.'; if (box) box.className = 'warn'; return; }
  const f = m.diapositivas.some((d) => d.fuentes && Object.keys(d.fuentes).length) && m.diapositivas.some((d) => d.colores && Object.keys(d.colores).length);
  const pop = m.diapositivas.reduce((t, d) => t + d.popups.length, 0);
  el.textContent = 'Modelo: ' + m.diapositivas.length + ' diapositivas, ' + (m.ruta ? m.ruta.length : 0) + ' pasos de ruta, ' + pop + ' ventanas emergentes' + (f ? '' : ' · sin datos de fuente/color (vuelve a grabarlo para evaluarlos)') + ' · ' + (m.url || '');
  if (box) box.className = f ? 'okbox' : 'warn';
}
function lockUi(on) {
  ['go', 'manual', 'alumno', 'corregir', 'borrar', 'mfile', 'addrow', 'pegarbtn', 'detbtn', 'ordbtn', 'dlmodel', 'saveproj', 'openproj', 'openbtn', 'pname'].forEach((i) => { const e = $(i); if (e) e.disabled = !!on; });
  const c = $('corregir'); if (c) c.disabled = B.running && B.kind !== 'corr';      // durante una corrección sigue activo: añade a la cola
  const s = $('stopc'); if (s) s.disabled = !B.running;
}

/* ---------- Puntuación ---------- */
const mark = (x) => Math.round(x * 100) / 100;
const ratio = (m, s) => (m === 0 && s === 0 ? 10 : 10 * Math.min(m, s) / Math.max(m, s));
// solo se sanciona tener MENOS que el profesor; tener más cuenta como correcto
const atLeast = (m, s) => (s >= m ? 10 : 10 * s / m);
function fontScore(fm, fs) {
  const tot = Object.values(fm).reduce((t, v) => t + v, 0); if (!tot) return null;
  let ok = 0; Object.entries(fm).forEach(([k, v]) => { if (fs[k]) ok += v; });
  return 10 * ok / tot;
}
const SC = {
  img: (a, b) => (a.imagenes.total > 0 ? atLeast(a.imagenes.total, b.imagenes.total) : null),
  animN: (a, b) => (a.animaciones.total > 0 ? atLeast(a.animaciones.total, b.animaciones.total) : null),
  animT: (a, b) => {
    const ta = a.animaciones.tipos || {}, tb = b.animaciones.tipos || {}, ks = Object.keys(ta); if (!ks.length) return null;
    let up = 0, dn = 0; ks.forEach((k) => { up += Math.min(ta[k] || 0, tb[k] || 0); dn += ta[k] || 0; });
    return dn ? 10 * up / dn : null;
  },
  enl: (a, b, rows) => {
    const dm = new Set(a.enlaces.internos.map((l) => l.destino)); if (!dm.size) return null;
    const ds = new Set(b.enlaces.internos.map((l) => rows.tr(l.destino)));
    let ok = 0; dm.forEach((d) => { if (ds.has(d)) ok++; }); return 10 * ok / dm.size;
  },
  ext: (a, b) => (a.enlaces.externos.length > 0 ? ratio(a.enlaces.externos.length, b.enlaces.externos.length) : null),
  pop: (a, b) => (a.popups.length > 0 ? ratio(a.popups.length, b.popups.length) : null),
  font: (a, b) => (a.fuentes && Object.keys(a.fuentes).length ? fontScore(a.fuentes, b.fuentes || {}) : null),
  color: (a, b) => (a.colores && Object.keys(a.colores).length ? fontScore(a.colores, b.colores || {}) : null),
  texto: (a, b) => {
    const W = (r) => new Set(normTxt((r.textosTodos && r.textosTodos.length ? r.textosTodos : [r.titulo, ...(r.textos || [])]).join(' ')).match(/[a-z0-9]{2,}/g) || []);
    const wa = W(a); if (!wa.size) return null; const wb = W(b); let ok = 0; wa.forEach((w) => { if (wb.has(w)) ok++; }); return 10 * ok / wa.size;
  },
};
/* Devuelve {filas:[{n,titulo,alcanzada,cel:{crit:nota|null}, media}], porCrit:{crit:media}, total, noAlcanzadas} */
function gradeStudent(model, st, edit, manual) {
  edit = edit || {}; manual = manual || {};
  const rows = compareReports(model, st), act = CRITERIOS.filter((k) => crit[k.id] && crit[k.id].on);
  let sw = 0, sp = 0; const pc = {}; act.forEach((k) => { pc[k.id] = { s: 0, n: 0 }; });
  const filas = rows.map((r) => {
    const cel = {}; let w = 0, p = 0;
    act.forEach((k) => {
      let v;
      if (!r.b) v = SC[k.id](r.a, emptyRec(0), rows) === null ? null : (crit.zeroUnreached ? 0 : null);
      else v = SC[k.id](r.a, r.b, rows);
      const ed = edit[r.n] && edit[r.n][k.id];
      cel[k.id] = ed !== undefined && ed !== null ? ed : (v === null || v === undefined ? null : mark(v));
      if (ed !== undefined && ed !== null) { (cel._ed = cel._ed || {})[k.id] = 1; }
      if (cel[k.id] !== null) { const wt = crit[k.id].w; w += wt; p += wt * cel[k.id]; sw += wt; sp += wt * cel[k.id]; pc[k.id].s += cel[k.id]; pc[k.id].n++; }
    });
    return { n: r.n, titulo: r.titulo, alcanzada: !!r.b, cel, media: w ? mark(p / w) : null, diffs: r.diffs };
  });
  const porCrit = {}; act.forEach((k) => { porCrit[k.id] = pc[k.id].n ? mark(pc[k.id].s / pc[k.id].n) : null; });
  // nota total = media de las notas de cada criterio ponderada por su importancia (los apartados manuales entran como un criterio más)
  let tw = 0, tp = 0; act.forEach((k) => { const v = porCrit[k.id]; if (v !== null) { tw += crit[k.id].w; tp += crit[k.id].w * v; } });
  extras.filter((e) => e.on).forEach((e) => { const v = manual[e.id]; if (v !== undefined && v !== null) { porCrit[e.id] = v; tw += e.w; tp += e.w * v; } else porCrit[e.id] = null; });
  return { filas, porCrit, total: tw ? mark(tp / tw) : null, noAlcanzadas: filas.filter((f) => !f.alcanzada).length, extras: rows.extras || [] };
}

/* ---------- Datos compactos para guardar ---------- */
function compactRep(r) {
  return { url: r.url, fecha: r.fecha, totalPaginas: r.totalPaginas, avisos: (r.avisos || []).slice(0, 20),
    diapositivas: r.diapositivas.map((d) => ({ n: d.n, titulo: d.titulo, textos: (d.textos || []).slice(0, 40), textosTodos: (d.textosTodos || []).slice(0, 150), colores: d.colores || {},
      imagenes: { total: d.imagenes.total }, animaciones: { total: d.animaciones.total, tipos: d.animaciones.tipos },
      enlaces: { internos: d.enlaces.internos.map((l) => ({ destino: l.destino, texto: l.texto })), externos: d.enlaces.externos.map((l) => ({ href: l.href, texto: l.texto })) },
      popups: d.popups.map((p) => ({ elemento: p.elemento })), notas: d.notas || [], fuentes: d.fuentes || {} })) };
}
const grade = (a) => { const m = getModel(); if (!m || !a.data || !a.data.diapositivas) return null; try { return gradeStudent(m, a.data, a.edit, a.manual); } catch (e) { return null; } };
const fmt = (x) => (x === null || x === undefined ? '—' : String(x).replace('.', ','));
const cls = (v) => (v === null || v === undefined ? 'na' : v >= 8 ? 'ok' : v >= 5 ? 'mid' : 'bad');

/* ---------- Lista de alumnos ---------- */
function addAlumno(nombre, url) { alumnos.push({ id: ++uid, nombre: nombre || '', url: url || '', estado: 'pendiente' }); }
function renderAlumnos() {
  const root = $('lista'); root.replaceChildren();
  if (!alumnos.length) root.append(h('div', { class: 'muted' }, 'Aún no hay alumnos. Añade una fila o pega una lista.'));
  alumnos.forEach((a) => {
    const g = grade(a);
    root.append(h('div', { class: 'arow' },
      h('input', { class: 'an', placeholder: 'Nombre (se detecta solo)', value: a.nombre, readonly: !!a.ext, title: a.ext ? 'Alumno del cuaderno de evaluación' : '', onchange: (e) => { a.nombre = e.target.value; saveState(); renderResultados(); } }),
      h('input', { class: 'au', placeholder: 'https://view.genially.com/...', value: a.url, onchange: (e) => { a.url = e.target.value.trim(); if (a.estado !== 'pendiente') a.estado = 'pendiente'; saveState(); renderAlumnos(); } }),
      h('span', { class: 'est e-' + a.estado.replace(' ', '') }, a.estado + (a.error ? ': ' + a.error : '') + (SESION && !a.ext ? ' · sin emparejar con el cuaderno' : '')),
      h('b', { class: 'nota ' + cls(g && g.total) }, g ? fmt(g.total) : ''),
      h('button', { class: 'mini', title: 'Volver a corregir a este alumno (se añade a la cola)', disabled: B.running && B.kind !== 'corr' || a.estado === 'en curso' || a.estado === 'en cola', onclick: () => corregir([a.id]) }, '↻'),
      a.ext ? h('span', {}) : h('button', { class: 'mini rojo', title: 'Quitar', disabled: B.running && B.kind !== 'corr' || a.estado === 'en curso', onclick: () => { alumnos = alumnos.filter((x) => x !== a); B.queue = B.queue.filter((q) => q !== a.id); delete full[a.id]; idb.set(capKey(a), null); saveState(); renderAlumnos(); renderResultados(); } }, '✕')));
  });
}
function pegarLista(texto) {
  let n = 0;
  texto.split(/\r?\n/).forEach((ln) => {
    const m = /https?:\/\/\S+/.exec(ln); if (!m) return;
    const nombre = ln.replace(m[0], '').replace(/[;,\t|\-–:]+\s*$/, '').replace(/^\s*[;,\t|\-–:]+/, '').trim();
    addAlumno(nombre, m[0].replace(/[),.;]+$/, '')); n++;
  });
  return n;
}

/* ---------- Nombres: detección y orden por primer apellido ---------- */
const PART = new Set(['de', 'del', 'la', 'las', 'los', 'y', 'e', 'san', 'santa', 'da', 'do', 'dos', 'das', 'di', 'van', 'von', 'der', 'den', 'el', 'al']);
const plano = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
// «Apellido1 Apellido2, Nombre» se respeta tal cual; si no, se supone «Nombre Apellido1 Apellido2» (con 4 o más palabras, dos nombres)
function claveApellido(n) {
  const s = String(n || '').trim(); if (!s) return null;
  let ape, nom;
  if (s.includes(',')) { const [a, ...r] = s.split(','); ape = a.trim(); nom = r.join(' ').trim(); }
  else {
    const words = []; let pend = [];
    s.split(/\s+/).forEach((t) => { if (PART.has(t.toLowerCase()) && words.length) pend.push(t); else { words.push([...pend, t].join(' ')); pend = []; } });
    if (pend.length) words.push(pend.join(' '));
    const given = words.length >= 4 ? 2 : 1;
    ape = words.slice(given).join(' '); nom = words.slice(0, given).join(' ');
    if (!ape) { ape = nom; nom = ''; }
  }
  ape = ape.replace(/^((de|del|la|las|los|y|el|al|da|do|dos|das|di|van|von|der|den)\s+)+/i, '');   // «de la Torre» se ordena por T
  return plano(ape + ' ' + nom);
}
function ordenarAlumnos() {
  const k = (a) => claveApellido(a.nombre);
  alumnos = alumnos.map((a, i) => ({ a, i })).sort((x, y) => { const p = k(x.a), q = k(y.a); if (p === null && q === null) return x.i - y.i; if (p === null) return 1; if (q === null) return -1; return p < q ? -1 : p > q ? 1 : x.i - y.i; }).map((x) => x.a);
}
async function leerAutor(url) {
  let win;
  try {
    win = await chrome.windows.create({ url, type: 'popup', width: 700, height: 450, left: 20, top: 20, focused: false });
    S.tabId = win.tabs[0].id;
    const t0 = Date.now();
    while (Date.now() - t0 < 30000 && !B.cancel) {
      await sleep(1500);
      let r = null; try { r = await call('author'); } catch (e) {}
      if (r && r.texto) return r.texto;
      if (r && r.titulo && Date.now() - t0 > 9000) return r.titulo;     // el título solo vale si el texto no aparece
    }
    return null;
  } finally { if (win) { try { await chrome.windows.remove(win.id); } catch (e) {} } }
}
const say = (m) => { ['prog', 'prog2'].forEach((i) => { if ($(i)) $(i).textContent = m; }); };
async function detectarNombres(ids) {
  if (B.running) return;
  const cola = alumnos.filter((a) => a.url && (ids ? ids.includes(a.id) : !String(a.nombre || '').trim()));
  if (!cola.length) { say('Todos los alumnos con enlace ya tienen nombre.'); ordenarAlumnos(); saveState(); renderAlumnos(); renderResultados(); return; }
  B.running = true; B.cancel = false; lockUi(true);
  let ok = 0; const fallo = [];
  try {
    for (let i = 0; i < cola.length && !B.cancel; i++) {
      const a = cola[i]; say( 'Leyendo el nombre del autor (' + (i + 1) + ' de ' + cola.length + ')…');
      let nombre = null; try { nombre = await leerAutor(a.url); } catch (e) {}
      if (nombre) { a.nombre = nombre; ok++; } else fallo.push(a.url);
      renderAlumnos();
    }
  } finally {
    B.running = false; lockUi(false); const emp = emparejar(); ordenarAlumnos(); saveState(); renderAlumnos(); renderResultados();
    say( 'Nombres detectados: ' + ok + ' de ' + cola.length + '. Ordenados por primer apellido.' + (SESION ? ' Emparejados con el cuaderno: ' + emp + '.' : '') + (fallo.length ? ' No se encontró el nombre en ' + fallo.length + ' (escríbelo tú a mano; los que no tienen nombre quedan al final).' : ''));
  }
}

/* ---------- Criterios ---------- */
function renderCrit() {
  const root = $('crit'); root.replaceChildren();
  CRITERIOS.forEach((k) => {
    const c = crit[k.id];
    root.append(h('label', { class: 'crow' },
      h('input', { type: 'checkbox', checked: c.on, onchange: (e) => { c.on = e.target.checked; saveState(); renderAlumnos(); renderResultados(); } }),
      h('span', { class: 'cn' }, h('b', {}, k.nombre), h('small', {}, k.ayuda)),
      h('span', {}, 'Importancia ', h('select', { onchange: (e) => { c.w = +e.target.value; saveState(); renderAlumnos(); renderResultados(); } },
        [1, 2, 3, 4, 5].map((v) => h('option', { value: v, selected: v === c.w }, v + (v === 1 ? ' (poca)' : v === 5 ? ' (máxima)' : '')))))));
  });
  root.append(h('div', { class: 'sec' }, 'Apartados manuales (la nota la pones tú en la tabla de resultados)'));
  extras.forEach((e) => root.append(h('div', { class: 'crow' },
    h('input', { type: 'checkbox', checked: e.on, onchange: (ev) => { e.on = ev.target.checked; saveState(); renderAlumnos(); renderResultados(); } }),
    h('input', { class: 'xn', value: e.nombre, placeholder: 'Nombre (p. ej. Comportamiento)', onchange: (ev) => { e.nombre = ev.target.value.trim() || 'Apartado'; saveState(); renderResultados(); } }),
    h('span', {}, 'Importancia ', h('select', { onchange: (ev) => { e.w = +ev.target.value; saveState(); renderAlumnos(); renderResultados(); } }, [1, 2, 3, 4, 5].map((v) => h('option', { value: v, selected: v === e.w }, v + (v === 1 ? ' (poca)' : v === 5 ? ' (máxima)' : '')))),
      h('button', { class: 'mini rojo', title: 'Quitar este apartado', onclick: () => { extras = extras.filter((x) => x !== e); alumnos.forEach((a) => { if (a.manual) delete a.manual[e.id]; }); saveState(); renderCrit(); renderAlumnos(); renderResultados(); } }, '✕')))));
  root.append(h('button', { onclick: () => { extras.push({ id: 'x' + Date.now().toString(36), nombre: 'Comportamiento', on: true, w: 3 }); saveState(); renderCrit(); renderAlumnos(); renderResultados(); } }, '+ Añadir apartado manual'));
  root.append(h('label', { class: 'crow' }, h('input', { type: 'checkbox', checked: crit.zeroUnreached, onchange: (e) => { crit.zeroUnreached = e.target.checked; saveState(); renderAlumnos(); renderResultados(); } }),
    h('span', { class: 'cn' }, h('b', {}, 'Si no se llega a una diapositiva, sus elementos cuentan como 0'), h('small', {}, 'Si se desmarca, las diapositivas a las que no se llegó no se tienen en cuenta en la nota (solo se avisa).'))));
}

/* ---------- Corrección por lotes ---------- */
const nombreDe = (a, i) => a.nombre || 'Alumno ' + (i + 1);
async function corregir(ids) {
  if (B.running && B.kind !== 'corr') return alert('Espera a que termine la detección de nombres.');
  const model = getModel();
  if (!model || !model.ruta || !model.ruta.length) return alert('Falta el modelo. Graba la presentación del profesor en modo manual (con esta versión) o carga un modelo .json guardado con esta versión.');
  const nuevos = alumnos.filter((a) => (ids ? ids.includes(a.id) : a.estado !== 'corregido') && a.url && a.estado !== 'en curso' && a.estado !== 'en cola');
  if (!nuevos.length) { if (!B.running) alert(ids ? 'Ese alumno no tiene enlace o ya está en la cola.' : 'No hay alumnos pendientes con enlace.'); return; }
  nuevos.forEach((a) => { B.queue.push(a.id); a.estado = 'en cola'; a.error = ''; });
  B.total += nuevos.length; renderAlumnos();
  if (B.running) { say('Añadido a la cola: ' + nuevos.length + '. Pendientes en cola: ' + B.queue.length + '.'); return; }   // el bucle que ya corre los irá cogiendo
  B.running = true; B.kind = 'corr'; B.cancel = false; B.done = 0; B.total = nuevos.length; lockUi(true);
  let release = null, lockP = null, renombrados = false;
  try { chrome.power && chrome.power.requestKeepAwake('system'); } catch (e) {}
  try { if (navigator.locks) lockP = navigator.locks.request('genially-corrector', () => new Promise((r) => { release = r; })); } catch (e) {}
  try {
    while (B.queue.length && !B.cancel) {
      const id = B.queue.shift(), a = alumnos.find((x) => x.id === id); if (!a) { B.total--; continue; }
      const idx = alumnos.indexOf(a);
      a.estado = 'en curso'; a.error = ''; delete a.edit; renderAlumnos();
      say('Corrigiendo ' + (B.done + 1) + ' de ' + B.total + ': ' + nombreDe(a, idx) + '… (en cola: ' + B.queue.length + '). Puedes minimizar el panel o seguir trabajando en otras ventanas; la ventana del alumno se abre pequeña, déjala sin tapar del todo. Mientras tanto puedes añadir más alumnos a la cola con ↻.');
      try {
        const res = await runSession({ url: a.url, model, driver: (ctx) => studentDriver(ctx, model), quiet: true, batch: true });
        if (!res.ok) { a.estado = 'error'; a.error = (rep.avisos.find((x) => /No se pudo cargar|cerró/.test(x)) || 'no se pudo analizar'); }
        else {
          full[a.id] = JSON.parse(JSON.stringify(rep)); a.data = compactRep(rep);
          if (!String(a.nombre || '').trim() && rep.autor && (rep.autor.texto || rep.autor.titulo)) { a.nombre = rep.autor.texto || rep.autor.titulo; renombrados = true; }
          a.caps = {}; rep.diapositivas.forEach((d) => { if (d.captura) a.caps[d.n] = d.captura; }); idb.set(capKey(a), Object.keys(a.caps).length ? a.caps : null);
          a.estado = (B.cancel || rep.avisos.some((x) => /No alcanzadas|Se cerró la ventana/.test(x))) ? 'incompleto' : 'corregido';
        }
      } catch (e) { a.estado = 'error'; a.error = e.message; }
      B.done++;
      saveState(); renderAlumnos(); renderResultados();
    }
    say(B.cancel ? 'Corrección detenida.' : 'Corrección terminada (' + B.done + ' alumno(s)).');
  } finally {
    B.running = false; B.kind = ''; B.queue = [];
    alumnos.forEach((a) => { if (a.estado === 'en curso' || a.estado === 'en cola') a.estado = 'pendiente'; });
    if (release) release(); try { chrome.power && chrome.power.releaseKeepAwake(); } catch (e) {}
    if (renombrados) { emparejar(); ordenarAlumnos(); }
    lockUi(false); saveState(); renderAlumnos(); renderResultados();
  }
}

/* ---------- Resultados ---------- */
function renderResultados() {
  const root = $('resultados'); root.replaceChildren();
  const done = alumnos.map((a, i) => ({ a, i, g: grade(a) })).filter((x) => x.g);
  if (!done.length) { root.append(h('div', { class: 'muted' }, 'Aún no hay alumnos corregidos.')); return; }
  const act = CRITERIOS.filter((k) => crit[k.id] && crit[k.id].on), cols = activos();
  const avg = (arr) => { const v = arr.filter((x) => x !== null && x !== undefined); return v.length ? mark(v.reduce((t, x) => t + x, 0) / v.length) : null; };
  root.append(h('div', { class: 'cards' }, mkCard(fmt(avg(done.map((x) => x.g.total))), 'nota media de la clase'), mkCard(done.length, 'alumnos corregidos'),
    mkCard(fmt(Math.max(...done.map((x) => x.g.total || 0))), 'nota más alta'), mkCard(fmt(Math.min(...done.map((x) => x.g.total === null ? 10 : x.g.total))), 'nota más baja')));
  root.append(h('table', {}, h('tr', {}, h('th', {}, 'Alumno'), cols.map((k) => h('th', { class: 'n' }, k.nombre + (k.manual ? ' ✎' : ''))), h('th', { class: 'n' }, 'NOTA TOTAL')),
    done.map((x) => h('tr', {}, h('td', {}, nombreDe(x.a, x.i) + (x.a.estado === 'incompleto' ? ' (incompleto)' : '')), cols.map((k) => (k.manual ? h('td', { class: 'n ' + cls(x.g.porCrit[k.id]) + ' edited' }, manualInput(x.a, k.id, x.g.porCrit[k.id])) : h('td', { class: 'n ' + cls(x.g.porCrit[k.id]) }, fmt(x.g.porCrit[k.id])))), h('td', { class: 'n tot ' + cls(x.g.total) }, fmt(x.g.total)))),
    h('tr', { class: 'mediaRow' }, h('td', {}, h('b', {}, 'Media de la clase')), cols.map((k) => h('td', { class: 'n' }, fmt(avg(done.map((x) => x.g.porCrit[k.id]))))), h('td', { class: 'n tot' }, fmt(avg(done.map((x) => x.g.total)))))));
  root.append(h('p', { class: 'muted' }, 'Cada celda es la media de las diapositivas en las que ese elemento existe en la presentación del profesor (si no está en la del profesor, no se busca ni se puntúa). La nota total es la media de las notas de cada criterio, ponderada por su importancia (los apartados manuales ✎ cuentan como un criterio más y solo si les pones nota). Escala 0–10. Verde ≥ 8, naranja ≥ 5, rojo < 5.'));
  done.forEach((x) => {
    const g = x.g, d = h('details', {}, h('summary', {}, nombreDe(x.a, x.i) + ' · nota ' + fmt(g.total) + (g.noAlcanzadas ? ' · ' + g.noAlcanzadas + ' diapositiva(s) no alcanzada(s)' : '') + (nEdits(x.a) ? ' · ' + nEdits(x.a) + ' nota(s) modificada(s) por ti' : '')));
    d.open = openSet.has(x.a.id); d.ontoggle = () => { if (d.open) openSet.add(x.a.id); else openSet.delete(x.a.id); };
    d.append(h('p', { class: 'muted' }, 'Puedes corregir a mano cualquier nota de la tabla (0–10); la media y la nota total se recalculan. Las celdas cambiadas se marcan con borde azul.'));
    if (nEdits(x.a)) d.append(h('button', { class: 'mini', onclick: () => { delete x.a.edit; saveState(); renderAlumnos(); renderResultados(); } }, 'Quitar mis cambios'));
    d.append(h('table', {}, h('tr', {}, h('th', { class: 'n' }, 'Nº'), h('th', {}, 'Diapositiva'), act.map((k) => h('th', { class: 'n' }, k.nombre)), h('th', { class: 'n' }, 'Media')),
      g.filas.map((f) => h('tr', {}, h('td', { class: 'n' }, f.n), h('td', {}, (f.titulo || '—').slice(0, 40)), act.map((k) => h('td', { class: 'n ' + cls(f.cel[k.id]) + (f.cel._ed && f.cel._ed[k.id] ? ' edited' : '') }, h('input', { class: 'ce', value: fmt(f.cel[k.id]), title: 'Pulsa para cambiar la nota (0–10). Déjala vacía para volver a la automática.', onchange: (e) => setEdit(x.a, f.n, k.id, e.target.value) }))), h('td', { class: 'n tot ' + cls(f.media) }, fmt(f.media)))),
      h('tr', { class: 'mediaRow' }, h('td', {}), h('td', {}, h('b', {}, 'Media del elemento')), act.map((k) => h('td', { class: 'n' }, fmt(g.porCrit[k.id]))), h('td', { class: 'n tot' }, fmt(g.total)))));
    const mx = extras.filter((e) => e.on);
    if (mx.length) d.append(h('div', { class: 'sec' }, 'Apartados manuales'), h('div', {}, mx.map((e) => h('span', { class: 'mx' }, (e.nombre || 'Apartado') + ': ', manualInput(x.a, e.id, g.porCrit[e.id])))));
    const obs = g.filas.filter((f) => f.diffs.length), avisos = x.a.data.avisos || [];
    const nObs = obs.reduce((t, f) => t + f.diffs.length, 0) + (g.extras.length ? 1 : 0) + avisos.length;
    if (nObs) {
      const od = h('details', { class: 'obs' }, h('summary', {}, '📝 Observaciones y avisos (' + nObs + ')'),
        obs.length ? h('ul', {}, obs.map((f) => h('li', {}, h('b', {}, 'Diapositiva ' + f.n + ': '), f.diffs.join(' ')))) : null,
        g.extras.length ? h('div', { class: 'muted' }, 'Páginas del alumno que no se parecen a ninguna del modelo: ' + g.extras.join(', ') + '.') : null,
        avisos.length ? [h('div', { class: 'sec' }, 'Avisos del recorrido automático'), avisos.map((w) => h('div', { class: 'warn' }, w))] : null);
      od.open = openSet.has('o' + x.a.id); od.ontoggle = () => { if (od.open) openSet.add('o' + x.a.id); else openSet.delete('o' + x.a.id); };
      d.append(od);
    }
    const caps = x.a.caps || {}, pgs = Object.keys(caps).map(Number).sort((p, q) => p - q);
    if (pgs.length) {
      let s2m = {}; try { s2m = compareReports(getModel(), x.a.data).s2m || {}; } catch (e) {}
      const tit = (n) => { const d = x.a.data.diapositivas.find((y) => y.n === n); return (d && d.titulo) || ''; };
      const cd = h('details', {}, h('summary', {}, '📷 Capturas de las diapositivas del alumno (' + pgs.length + ')'),
        h('div', { class: 'thumbs' }, pgs.map((n) => h('figure', {}, h('img', { src: caps[n], title: 'Pulsa para ampliar', onclick: () => lightbox(caps[n]) }),
          h('figcaption', {}, 'Pág. ' + n + (s2m[n] ? ' (modelo ' + s2m[n] + ')' : '') + (tit(n) ? ' · ' + tit(n).slice(0, 28) : ''))))));
      cd.open = openSet.has('c' + x.a.id); cd.ontoggle = () => { if (cd.open) openSet.add('c' + x.a.id); else openSet.delete('c' + x.a.id); };
      d.append(cd);
    } else if (x.a.estado !== 'pendiente') d.append(h('div', { class: 'muted' }, 'Sin capturas (se hacen al corregir al alumno).'));
    root.append(d);
  });
}
const openSet = new Set();
function manualInput(a, id, v) {
  return h('input', { class: 'ce', value: fmt(v), title: 'Escribe tu nota (0–10). Vacío = sin nota.', onchange: (e) => setManual(a, id, e.target.value) });
}
function setManual(a, id, txt) {
  const t = String(txt).trim().replace(',', '.'); a.manual = a.manual || {};
  if (t === '' || t === '—') delete a.manual[id];
  else { const v = parseFloat(t); if (isNaN(v)) return renderResultados(); a.manual[id] = mark(Math.max(0, Math.min(10, v))); }
  saveState(); renderAlumnos(); renderResultados();
}
function lightbox(src) {
  const o = h('div', { class: 'lb', onclick: () => o.remove() }, h('img', { src }));
  document.body.append(o);
}
const nEdits = (a) => Object.values(a.edit || {}).reduce((t, o) => t + Object.keys(o).length, 0);
function setEdit(a, n, c, txt) {
  const t = String(txt).trim().replace(',', '.');
  a.edit = a.edit || {}; a.edit[n] = a.edit[n] || {};
  if (t === '' || t === '—') delete a.edit[n][c];
  else { const v = parseFloat(t); if (isNaN(v)) return renderResultados(); a.edit[n][c] = mark(Math.max(0, Math.min(10, v))); }
  if (!Object.keys(a.edit[n]).length) delete a.edit[n];
  saveState(); renderAlumnos(); renderResultados();
}
function csvNotas() {
  const act = activos(), q = (s) => '"' + String(s).replace(/"/g, '""') + '"';
  const lines = [['Alumno', 'Enlace', ...act.map((k) => k.nombre), 'Nota total'].map(q).join(';')];
  alumnos.forEach((a, i) => { const g = grade(a); if (g) lines.push([q(nombreDe(a, i)), q(a.url), ...act.map((k) => fmt(g.porCrit[k.id])), fmt(g.total)].join(';')); });
  return '﻿' + lines.join('\r\n');
}

/* ---------- Eventos ---------- */
$('addrow').onclick = () => { addAlumno('', ''); saveState(); renderAlumnos(); };
$('pegarbtn').onclick = () => {
  const n = pegarLista($('pegar').value); if (!n) return alert('No encontré enlaces en el texto. Pon un enlace por línea (con o sin nombre).');
  $('pegar').value = ''; emparejar(); saveState(); renderAlumnos();
  if (alumnos.some((a) => a.url && !String(a.nombre || '').trim())) detectarNombres(null); else { ordenarAlumnos(); saveState(); renderAlumnos(); }
};
$('detbtn').onclick = () => detectarNombres(null);
$('ordbtn').onclick = () => { ordenarAlumnos(); saveState(); renderAlumnos(); renderResultados(); };
$('corregir').onclick = () => corregir(null);
$('stopc').onclick = () => { B.cancel = true; M.stop = true; };
$('openbtn').onclick = () => $('openproj').click();
$('pname').value = lsGet(KP + 'nombre', ''); $('pname').onchange = saveState;
// Abre el diálogo de «Guardar como…» del sistema para elegir carpeta y nombre; si el navegador no lo permite, descarga el archivo
async function guardarComo(nombre, contenido) {
  if (typeof window !== 'undefined' && window.showSaveFilePicker) {
    let fh;
    try { fh = await window.showSaveFilePicker({ suggestedName: nombre, types: [{ description: 'Proyecto de Genially (.json)', accept: { 'application/json': ['.json'] } }] }); }
    catch (e) { if (e && e.name === 'AbortError') return; fh = null; }
    if (fh) {
      try { const w = await fh.createWritable(); await w.write(contenido); await w.close(); say('Proyecto guardado en «' + fh.name + '».'); return; }
      catch (e) { alert('No se pudo escribir el archivo (' + e.message + '). Se descargará en la carpeta de descargas.'); }
    }
  }
  save(nombre, 'application/json', contenido); say('Proyecto descargado como «' + nombre + '».');
}
$('saveproj').onclick = () => {
  const p = { tipo: 'proyecto-genially', version: 1, guardado: new Date().toISOString(), modelo: getModel(), nombre: $('pname').value.trim(), extras, criterios: crit, alumnos: alumnos.map((a) => ({ ...a, caps: a.caps || {} })) };
  const slug = ($('pname').value.trim() || 'proyecto').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'proyecto';
  guardarComo(slug + '-' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify(p));
};
$('openproj').onchange = async (ev) => {
  const f = ev.target.files[0]; ev.target.value = ''; if (!f) return;
  try {
    const j = JSON.parse(await f.text());
    if (j.tipo !== 'proyecto-genially' || !Array.isArray(j.alumnos)) throw new Error('no es un proyecto guardado con esta herramienta');
    if ((alumnos.length || getModel()) && !confirm('Se reemplazarán el modelo, los alumnos y las notas actuales por los del proyecto. ¿Continuar?')) return;
    alumnos.forEach((a) => idb.set(capKey(a), null));
    fileModel = j.modelo || null; lastModel = null;
    crit = Object.assign(defaultCrit(), j.criterios || {}); CRITERIOS.forEach((k) => { if (!crit[k.id]) crit[k.id] = { on: true, w: k.w }; });
    extras = Array.isArray(j.extras) ? j.extras : []; $('pname').value = j.nombre || '';
    alumnos = j.alumnos; uid = 0; alumnos.forEach((a, i) => { a.id = ++uid; if (a.estado === 'en curso' || a.estado === 'en cola') a.estado = 'pendiente'; if (a.caps && Object.keys(a.caps).length) idb.set(capKey(a), a.caps); });
    full = {}; saveState(); renderModelInfo(); renderCrit(); renderAlumnos(); renderResultados();
    $('prog').textContent = 'Proyecto «' + (j.nombre || 'sin nombre') + '» cargado: ' + alumnos.length + ' alumno(s).';
  } catch (e) { alert('No se pudo abrir el proyecto: ' + e.message); }
};
$('csv').onclick = () => save('notas-genially.csv', 'text/csv;charset=utf-8', csvNotas());
$('dlmodel').onclick = () => { const m = getModel(); if (!m) return alert('No hay modelo.'); save('modelo-genially.json', 'application/json', JSON.stringify(m)); };
$('borrar').onclick = () => { if (!confirm('¿Borrar todos los alumnos y sus notas?')) return; alumnos.forEach((a) => idb.set(capKey(a), null)); alumnos = []; full = {}; saveState(); renderAlumnos(); renderResultados(); };

/* ---------- Conexión con el Cuaderno de Evaluación ---------- */
const CX = { info: null, timer: null };
const tokensNombre = (t) => plano(t).replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((x) => x.length >= 2 && !PART.has(x));
// Parecido entre dos nombres: hacen falta al menos dos palabras en común (nombre + apellido, o dos apellidos)
function parecidoNombre(a, b) {
  const A = new Set(tokensNombre(a)), B2 = new Set(tokensNombre(b)); if (!A.size || !B2.size) return 0;
  let i = 0; A.forEach((t) => { if (B2.has(t)) i++; });
  return i >= 2 ? i + i / Math.max(A.size, B2.size) : 0;
}
// Las filas añadidas aquí (pegando enlaces) se unen al alumno del cuaderno con el mismo nombre que aún no tiene enlace
function emparejar() {
  if (!SESION || B.running) return 0; let n = 0;
  alumnos.filter((a) => !a.ext && a.url && String(a.nombre || '').trim()).forEach((t) => {
    const c = alumnos.filter((x) => x.ext && !x.url).map((x) => [parecidoNombre(t.nombre, x.nombre), x]).filter((x) => x[0] > 0).sort((x, y) => y[0] - x[0]);
    if (!c.length || (c[1] && c[1][0] === c[0][0])) return;      // sin candidato o empate: se deja sin emparejar
    const d = c[0][1];
    d.url = t.url; d.estado = t.estado || 'pendiente'; ['data', 'edit', 'manual', 'error'].forEach((k) => { if (t[k] !== undefined) d[k] = t[k]; });
    if (t.caps) { d.caps = t.caps; idb.set(capKey(d), t.caps); }
    idb.set(capKey(t), null);
    if (full[t.id]) { full[d.id] = full[t.id]; delete full[t.id]; }
    alumnos = alumnos.filter((x) => x !== t); n++;
  });
  return n;
}
// La lista de alumnos manda el cuaderno: se añaden los nuevos y se actualizan los nombres
function sincronizarAlumnos(lista) {
  const ids = new Set(lista.map((x) => x.id));
  lista.forEach((x) => {
    const a = alumnos.find((y) => y.ext === x.id);
    if (a) a.nombre = x.nombre; else alumnos.push({ id: ++uid, ext: x.id, nombre: x.nombre, url: '', estado: 'pendiente' });
  });
  alumnos.forEach((a) => { if (a.ext && !ids.has(a.ext)) delete a.ext; });   // ya no está en el cuaderno: queda como fila suelta
  emparejar(); ordenarAlumnos();
}
function aplicarProyecto(j) {
  fileModel = j.modelo || null; lastModel = null;
  crit = Object.assign(defaultCrit(), j.criterios || {}); CRITERIOS.forEach((k) => { if (!crit[k.id]) crit[k.id] = { on: true, w: k.w }; });
  extras = Array.isArray(j.extras) ? j.extras : [];
  alumnos = Array.isArray(j.alumnos) ? j.alumnos : [];
  alumnos.forEach((a) => {
    if (a.estado === 'en curso' || a.estado === 'en cola') a.estado = 'pendiente';
    if (a.caps && Object.keys(a.caps).length) idb.set(capKey(a), a.caps); else delete a.caps;   // las capturas vuelven desde el archivo del cuaderno
  });
  uid = alumnos.reduce((m, a) => Math.max(m, a.id || 0), 0); full = {};
}
function pintarBarra(estado, ok) {
  const bar = $('cuadernoBar'); if (!bar || !SESION) return;
  bar.style.display = '';
  bar.replaceChildren(
    h('b', {}, '📒 Conectado al Cuaderno de Evaluación'), CX.info && CX.info.titulo ? ' · ' + CX.info.titulo : '',
    h('div', { class: 'muted' }, 'Los alumnos vienen del cuaderno. Pon el enlace de Genially de cada uno (o pega la lista de enlaces: se emparejan por el nombre del autor). Todo (modelo grabado, enlaces, análisis, notas, cambios a mano y capturas) se envía solo al cuaderno cuando cambia; se guarda en el archivo al pulsar «💾 Guardar Archivo» en el cuaderno.'),
    h('span', { class: ok === false ? 'e-error' : 'muted', id: 'cxEstado' }, estado || ''));
  bar.className = ok === false ? 'warn' : 'okbox';
}
function programarEnvio() { clearTimeout(CX.timer); CX.timer = setTimeout(() => enviarNotas(false), 2500); }
async function enviarNotas(manual) {
  if (!SESION || !CX.info) return;
  const notas = {}; let n = 0;
  alumnos.forEach((a) => { if (!a.ext) return; const g = grade(a); if (g && g.total !== null) { notas[a.ext] = g.total; n++; } });
  const m = getModel();
  if (!n && !m && !manual) return;
  const proyecto = { tipo: 'proyecto-genially', version: 1, guardado: Date.now(), nombre: $('pname').value.trim(), criterios: crit, extras,
    modelo: m ? JSON.parse(JSON.stringify(m)) : null,                 // la grabación del modelo, con su ruta de clics
    alumnos: alumnos.map((a) => ({ ...a, caps: a.caps || {} })) };     // análisis, notas, cambios a mano y capturas
  pintarBarra('Enviando…');
  let r;
  try { r = await chrome.runtime.sendMessage({ tipo: 'enviar-notas', sesion: SESION, datos: { apartadoId: CX.info.apartadoId, notas, proyecto } }); }
  catch (e) { r = { ok: false, error: e.message }; }
  if (r && r.ok) pintarBarra('✓ ' + n + ' nota(s) enviada(s) al cuaderno a las ' + new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }) + '.', true);
  else pintarBarra('⚠ No se pudieron enviar las notas (' + ((r && r.error) || 'el cuaderno no está abierto') + '). Abre el cuaderno con este documento: se reintentará solo. Nada se pierde, todo queda guardado aquí.', false);
  clearTimeout(CX.reintento); if (!(r && r.ok)) CX.reintento = setTimeout(() => enviarNotas(false), 15000);
}
async function cargarSesion(inicial) {
  let p = null; try { p = (await chrome.storage.local.get('sesion:' + SESION))['sesion:' + SESION]; } catch (e) {}
  if (!p) { pintarBarra('⚠ No se encontraron los datos del cuaderno. Vuelve a abrir el corrector desde el apartado del cuaderno.', false); return; }
  CX.info = p;
  // el proyecto guardado en el cuaderno manda si es más reciente que lo que hay en este navegador
  if (inicial && !B.running && p.proyecto && (p.proyecto.guardado || 0) >= lsGet(KP + 'ts', 0) - 5000) aplicarProyecto(p.proyecto);
  sincronizarAlumnos(p.alumnos || []);
  $('pname').value = p.titulo || ''; document.title = 'Genially · ' + (p.titulo || 'cuaderno');
  saveState(false); renderModelInfo(); renderCrit(); renderAlumnos(); renderResultados(); lockUi(B.running); pintarBarra();
  await Promise.all(alumnos.map(async (a) => { if (!a.caps) { const c = await idb.get(capKey(a)); if (c) a.caps = c; } }));
  renderResultados();
}
if (SESION) {
  ['addrow', 'borrar', 'projbox'].forEach((i) => { const e = $(i); if (e) e.style.display = 'none'; });   // en el cuaderno todo se guarda solo
  $('pname').readOnly = true;
  try { chrome.runtime.onMessage.addListener((m) => { if (m && m.tipo === 'sesion-actualizada' && m.sesion === SESION) cargarSesion(false); }); } catch (e) {}
}

if (!fileModel && !lastModel) fileModel = lsGet(KP + 'modelo', null);
renderModelInfo(); renderCrit(); renderAlumnos(); renderResultados(); lockUi(false);
Promise.all(alumnos.map(async (a) => { const c = await idb.get(capKey(a)); if (c) a.caps = c; })).then(renderResultados);
if (SESION) cargarSesion(true);
